"""Optional read-only probe for the current official canvas closure metadata.

Prepared only; do not run until the parent review authorizes a live lease.
Never invokes a handler or application WASM function and never reads WASM memory.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import sys
import time
import uuid
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import (
    CLIENT_SHA256,
    ClientExtractor,
    connect_dedicated,
    is_official_client_url,
)
from tools.v2_controlled_transition_capture import is_project_headless_browser_process
from tools.v2_headless_research import read_controlled_document_observer_status


PLAN_PATH = ROOT / "runtime/research/v2/canvas-callback-scope-metadata-3-plan-20261002.json"
OUTPUT_PATH = ROOT / "runtime/research/v2/canvas-callback-scope-metadata-3-20261002.json"
PROFILE_PATH = (ROOT / "runtime/browser-profile").resolve()
HOST_SCRIPT = (ROOT / "tools/v2_headless_research.py").resolve()
HOST_LEASE_PATH = ROOT / "runtime/research/v2/headless-host.json"
WRITER_LEASE_PATH = ROOT / "runtime/research/v2/controlled-transition-writer.json"
TIMEOUT_SECONDS = 30
MIN_INITIAL_LEASE_MS = 60_000
MIN_END_LEASE_MS = 60_000
GENERATED_JS_SHA256 = "05b51675785a3f6568f4d80562dabb4f59a6130504c7a04c7de9cf777c33094e"
LOCAL_SOURCE_PINS = {
    ROOT / "runtime/research/v2/fae13d1d0a7683726db520ec5c687d67d701c874a5708aeb9bff6eaacf2f054c.wasm": CLIENT_SHA256,
    ROOT / "runtime/research/v2/client.js": GENERATED_JS_SHA256,
    ROOT / "runtime/research/v2/listener-source-captures-20261002/05b51675785a3f6568f4d80562dabb4f59a6130504c7a04c7de9cf777c33094e.js": GENERATED_JS_SHA256,
}
OFFICIAL_LISTENER = (GENERATED_JS_SHA256, 2270, 17)
ADAPTER_RECORD = 0x13E700
EVENTS = ("mousemove", "mousedown", "mouseup")
STATE_FIELDS = frozenset({"a", "b", "cnt", "dtor"})


def _lease_margin_and_owner() -> int:
    import psutil

    if not HOST_LEASE_PATH.is_file():
        raise RuntimeError("HOST_LEASE_MISSING")
    lease = json.loads(HOST_LEASE_PATH.read_text(encoding="utf-8"))
    if WRITER_LEASE_PATH.exists():
        raise RuntimeError("CONTROLLED_WRITER_ACTIVE")
    remaining = lease.get("deadline_monotonic_ms", 0) - time.monotonic_ns() // 1_000_000
    if (type(lease.get("pid")) is not int or lease["pid"] <= 0 or
            Path(lease.get("profile", "")).resolve() != PROFILE_PATH or
            remaining < MIN_INITIAL_LEASE_MS):
        raise RuntimeError("HOST_LEASE_OR_PROFILE_INVALID")
    try:
        process = psutil.Process(lease["pid"])
        args = process.cmdline()
        if (not process.name().lower().startswith(("python", "py")) or
                not any(Path(arg).resolve() == HOST_SCRIPT for arg in args
                        if arg.lower().endswith(".py"))):
            raise RuntimeError("HOST_PROCESS_MISMATCH")
        owners = []
        for child in process.children(recursive=True):
            try:
                if is_project_headless_browser_process(
                        child.name(), child.cmdline(), PROFILE_PATH):
                    owners.append(child.pid)
            except psutil.Error:
                continue
        if len(owners) != 1:
            raise RuntimeError("OWNED_CHROMIUM_COUNT_MISMATCH")
    except (psutil.Error, OSError) as exc:
        raise RuntimeError("HOST_PROCESS_UNVERIFIABLE") from exc
    return int(remaining)


async def _value(cdp: Any, expression: str) -> Any:
    response = await cdp.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": True,
        "awaitPromise": False,
        "userGesture": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("DOM_METADATA_EVALUATION_FAILED")
    remote = response.get("result") or {}
    if remote.get("subtype") == "error" or "value" not in remote:
        raise RuntimeError("DOM_METADATA_VALUE_UNAVAILABLE")
    return remote["value"]


async def _object(cdp: Any, expression: str, object_group: str) -> str:
    response = await cdp.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": False,
        "awaitPromise": False,
        "userGesture": False,
        "objectGroup": object_group,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("CANVAS_OBJECT_QUERY_FAILED")
    remote = response.get("result") or {}
    object_id = remote.get("objectId")
    if not isinstance(object_id, str) or not object_id:
        raise RuntimeError("CANVAS_OBJECT_ID_UNAVAILABLE")
    return object_id


async def _frame(cdp: Any) -> dict[str, Any]:
    response = await cdp.send("Page.getFrameTree", {})
    frame = (response.get("frameTree") or {}).get("frame")
    if not isinstance(frame, dict):
        raise RuntimeError("MAIN_FRAME_UNAVAILABLE")
    return {"frame_id": frame.get("id"), "loader_id": frame.get("loaderId"),
            "url": frame.get("url")}


async def _event_rows(cdp: Any, canvas_id: str) -> list[dict[str, Any]]:
    response = await cdp.send("DOMDebugger.getEventListeners", {
        "objectId": canvas_id,
        "depth": 0,
        "pierce": False,
    })
    rows = response.get("listeners")
    if not isinstance(rows, list):
        raise RuntimeError("CANVAS_LISTENER_ROWS_UNAVAILABLE")
    # Do not inspect other event types or any non-canvas DOM listener.
    selected = [row for row in rows if isinstance(row, dict) and row.get("type") in EVENTS]
    if len(selected) != len(EVENTS) or any(
            sum(row.get("type") == event for row in selected) != 1 for event in EVENTS):
        raise RuntimeError("OFFICIAL_CANVAS_MOUSE_LISTENER_SET_MISMATCH")
    return selected


async def _same_function_reference(cdp: Any, before_id: str, after_id: str) -> bool:
    if not isinstance(before_id, str) or not before_id or not isinstance(after_id, str) or not after_id:
        raise RuntimeError("HANDLER_REFERENCE_UNAVAILABLE_FOR_COMPARISON")
    response = await cdp.send("Runtime.callFunctionOn", {
        "objectId": before_id,
        "functionDeclaration": "function(other) { return this === other; }",
        "arguments": [{"objectId": after_id}],
        "returnByValue": True,
        "userGesture": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("HANDLER_REFERENCE_COMPARISON_FAILED")
    remote = response.get("result") or {}
    if remote.get("type") != "boolean" or not isinstance(remote.get("value"), bool):
        raise RuntimeError("HANDLER_REFERENCE_COMPARISON_MALFORMED")
    return remote["value"]


async def _same_handler_row(cdp: Any, before: dict[str, Any], after: dict[str, Any]) -> bool:
    if (before.get("type") != after.get("type") or
            before.get("useCapture") is not False or after.get("useCapture") is not False or
            before.get("scriptId") != after.get("scriptId") or
            (after.get("lineNumber"), after.get("columnNumber")) !=
            (OFFICIAL_LISTENER[1], OFFICIAL_LISTENER[2])):
        return False
    before_handler, after_handler = before.get("handler"), after.get("handler")
    if (not isinstance(before_handler, dict) or before_handler.get("type") != "function" or
            not isinstance(before_handler.get("objectId"), str) or not before_handler.get("objectId") or
            not isinstance(after_handler, dict) or after_handler.get("type") != "function" or
            not isinstance(after_handler.get("objectId"), str) or not after_handler.get("objectId")):
        return False
    script_id = after.get("scriptId")
    if not isinstance(script_id, str) or not script_id:
        return False
    source_response = await cdp.send("Debugger.getScriptSource", {"scriptId": script_id})
    source = source_response.get("scriptSource")
    if not isinstance(source, str) or hashlib.sha256(source.encode("utf-8")).hexdigest() != OFFICIAL_LISTENER[0]:
        return False
    return await _same_function_reference(cdp, before_handler["objectId"], after_handler["objectId"])


async def _properties(cdp: Any, object_id: str, *, own: bool) -> dict[str, Any]:
    response = await cdp.send("Runtime.getProperties", {
        "objectId": object_id,
        "ownProperties": own,
        "accessorPropertiesOnly": False,
        "generatePreview": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("SCOPE_PROPERTY_READ_FAILED")
    return response


def _remote_number(descriptor: dict[str, Any]) -> int | None:
    if descriptor.get("get") is not None or descriptor.get("set") is not None:
        return None
    value = descriptor.get("value")
    number = value.get("value") if isinstance(value, dict) else None
    if (not isinstance(value, dict) or value.get("type") != "number" or
            isinstance(number, bool) or not isinstance(number, (int, float)) or
            not math.isfinite(number) or int(number) != number):
        return None
    return int(number)


async def _inspect_one_handler(cdp: Any, row: dict[str, Any], object_ids: set[str]) -> dict[str, Any]:
    event = row.get("type")
    script_id = row.get("scriptId")
    handler = row.get("handler")
    if (row.get("useCapture") is not False or
            not isinstance(script_id, str) or not script_id or
            (row.get("lineNumber"), row.get("columnNumber")) !=
            (OFFICIAL_LISTENER[1], OFFICIAL_LISTENER[2]) or
            not isinstance(handler, dict) or handler.get("type") != "function" or
            not isinstance(handler.get("objectId"), str)):
        raise RuntimeError("OFFICIAL_CANVAS_HANDLER_IDENTITY_MISMATCH")
    handler_id = handler["objectId"]
    object_ids.add(handler_id)

    script_response = await cdp.send("Debugger.getScriptSource", {
        "scriptId": script_id,
    })
    source = script_response.get("scriptSource")
    if not isinstance(source, str):
        raise RuntimeError("OFFICIAL_HANDLER_SOURCE_UNAVAILABLE")
    source_hash = hashlib.sha256(source.encode("utf-8")).hexdigest()
    if source_hash != OFFICIAL_LISTENER[0]:
        raise RuntimeError("OFFICIAL_HANDLER_SOURCE_HASH_MISMATCH")

    function_props = await _properties(cdp, handler_id, own=False)
    scopes = [p.get("value") for p in function_props.get("internalProperties", [])
              if isinstance(p, dict) and p.get("name") == "[[Scopes]]"]
    if len(scopes) != 1 or not isinstance(scopes[0], dict):
        raise RuntimeError("FUNCTION_SCOPES_UNAVAILABLE_OR_AMBIGUOUS")
    scopes_id = scopes[0].get("objectId")
    if not isinstance(scopes_id, str):
        raise RuntimeError("FUNCTION_SCOPE_LIST_ID_UNAVAILABLE")
    object_ids.add(scopes_id)

    # Enumerate only the scope-list array to select the function's Closure
    # scope. Never request properties from Script or Global scopes.
    scope_list = await _properties(cdp, scopes_id, own=True)
    scope_candidates = []
    for descriptor in scope_list.get("result", []):
        if not isinstance(descriptor, dict) or not str(descriptor.get("name", "")).isdigit():
            continue
        value = descriptor.get("value")
        if (isinstance(value, dict) and isinstance(value.get("description"), str) and
                value["description"].startswith("Closure") and
                isinstance(value.get("objectId"), str)):
            scope_candidates.append(value["objectId"])
    if len(scope_candidates) != 1:
        raise RuntimeError("CLOSURE_SCOPE_UNAVAILABLE_OR_AMBIGUOUS")
    closure_scope_id = scope_candidates[0]
    object_ids.add(closure_scope_id)

    # Request the closure scope once, but consume only its `state` binding.
    # All other binding names and values are discarded and never followed.
    closure_bindings = await _properties(cdp, closure_scope_id, own=True)
    state_descriptors = [p for p in closure_bindings.get("result", [])
                         if isinstance(p, dict) and p.get("name") == "state"]
    if len(state_descriptors) != 1:
        raise RuntimeError("MUTABLE_CLOSURE_STATE_BINDING_UNAVAILABLE")
    state_remote = state_descriptors[0].get("value")
    if not isinstance(state_remote, dict) or not isinstance(state_remote.get("objectId"), str):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_OBJECT_UNAVAILABLE")
    state_id = state_remote["objectId"]
    object_ids.add(state_id)

    state_props = await _properties(cdp, state_id, own=True)
    allowed = {p.get("name"): p for p in state_props.get("result", [])
               if isinstance(p, dict) and p.get("name") in STATE_FIELDS}
    if not {"a", "b", "cnt"}.issubset(allowed):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_FIELDS_INCOMPLETE")
    a_value = _remote_number(allowed["a"])
    b_value = _remote_number(allowed["b"])
    count_value = _remote_number(allowed["cnt"])
    dtor_present = "dtor" in allowed
    if (a_value is None or b_value is None or count_value is None or
            a_value <= 0 or count_value < 1 or dtor_present):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_SHAPE_MISMATCH")

    # Do not publish `a`, `b`, handler/scope object IDs, or any raw heap ref.
    # b is checked only against the fixed adapter record established by the
    # pinned JS + WASM source ABI; it is not the inner callback vtable.
    return {
        "event": event,
        "source_sha256": source_hash,
        "source_location_matches": True,
        "bubble_listener": True,
        "handler_object_live": True,
        "handler_state_a_nonzero": True,
        "handler_state_b_matches_fixed_adapter_0x13e700": b_value == ADAPTER_RECORD,
        "handler_state_cnt_positive": True,
        "handler_state_dtor_absent": True,
        "inner_callback_vtable": "UNKNOWN_NOT_READ",
    }


def _write_receipt(receipt: dict[str, Any]) -> None:
    OUTPUT_PATH.write_text(json.dumps(receipt, ensure_ascii=True, indent=2) + "\n",
                           encoding="utf-8")
    observed = receipt.get("OBSERVED")
    rows = observed.get("callbacks", []) if isinstance(observed, dict) else []
    print(json.dumps({
        "output": str(OUTPUT_PATH),
        "verdict": receipt.get("VERDICT"),
        "event_count": len(rows),
        "adapter_matches": sum(
            row.get("handler_state_b_matches_fixed_adapter_0x13e700") is True
            for row in rows if isinstance(row, dict)),
    }, ensure_ascii=True))


async def _run() -> dict[str, Any]:
    base = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    base["VERDICT"] = "METADATA_UNAVAILABLE_FAIL_CLOSED"
    base["OBSERVED"] = {"status": "INCOMPLETE"}
    stage = "LEASE_PREFLIGHT"
    extractor = None
    debugger_enabled = False
    object_ids: set[str] = set()
    checked_rows = []
    canvas_id = None
    object_group = "canvas-scope-metadata-3-" + uuid.uuid4().hex
    try:
        stage = "LOCAL_SOURCE_PIN_PREFLIGHT"
        for path, expected_sha256 in LOCAL_SOURCE_PINS.items():
            if (not path.is_file() or
                    hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
                raise RuntimeError("LOCAL_PINNED_SOURCE_HASH_MISMATCH")

        lease_margin = _lease_margin_and_owner()
        async with async_playwright() as playwright:
            stage = "DEDICATED_BROWSER_ATTACH"
            browser = await connect_dedicated(playwright, ROOT)
            official_pages = [page for context in browser.contexts for page in context.pages
                              if is_official_client_url(page.url)]
            if len(official_pages) != 1:
                raise RuntimeError("OFFICIAL_PAGE_COUNT_MISMATCH")
            page = official_pages[0]
            if not is_official_client_url(page.url):
                raise RuntimeError("OFFICIAL_URL_REQUIRED")
            route_class = "ROOT" if page.url == "https://kiomet.com/" else "PARTY"

            stage = "PRISTINE_OBSERVER_PREFLIGHT"
            observer_before = await read_controlled_document_observer_status(page)

            stage = "PINNED_CLIENT_ATTACH"
            extractor = ClientExtractor(page)
            await extractor.attach()
            if extractor.cdp is None or extractor.time_origin is None:
                raise RuntimeError("PINNED_EXTRACTOR_ATTACH_INCOMPLETE")
            cdp = extractor.cdp
            frame_before = await _frame(cdp)
            origin_before = await _value(cdp, "performance.timeOrigin")
            if (frame_before.get("url") != page.url or
                    not isinstance(origin_before, (int, float)) or
                    isinstance(origin_before, bool) or
                    float(origin_before) != float(extractor.time_origin)):
                raise RuntimeError("INITIAL_DOCUMENT_IDENTITY_MISMATCH")

            stage = "CANVAS_DISCOVERY"
            canvas_count = await _value(cdp, "document.querySelectorAll('canvas').length")
            if type(canvas_count) is not int or canvas_count != 1:
                raise RuntimeError("CANVAS_COUNT_NOT_UNIQUE")
            canvas_id = await _object(cdp, "document.querySelector('canvas')", object_group)
            object_ids.add(canvas_id)

            stage = "OFFICIAL_CANVAS_LISTENER_LOOKUP"
            await cdp.send("Debugger.enable", {})
            debugger_enabled = True
            rows_before = await _event_rows(cdp, canvas_id)
            for event in EVENTS:
                row = next((item for item in rows_before if item.get("type") == event), None)
                if row is None:
                    raise RuntimeError("OFFICIAL_CANVAS_MOUSE_LISTENER_MISSING")
                checked_rows.append(await _inspect_one_handler(cdp, row, object_ids))

            stage = "HANDLER_LIVENESS_RECHECK"
            rows_after = await _event_rows(cdp, canvas_id)
            for event in EVENTS:
                before_row = next((item for item in rows_before if item.get("type") == event), None)
                after_row = next((item for item in rows_after if item.get("type") == event), None)
                if before_row is None or after_row is None:
                    raise RuntimeError("HANDLER_ROW_MISSING_DURING_RECHECK")
                if not await _same_handler_row(cdp, before_row, after_row):
                    raise RuntimeError("HANDLER_FUNCTION_REFERENCE_CHANGED_DURING_READ")

            stage = "FINAL_IDENTITY_CHECK"
            frame_after = await _frame(cdp)
            origin_after = await _value(cdp, "performance.timeOrigin")
            if (frame_before != frame_after or origin_before != origin_after or
                    frame_after.get("url") != page.url or
                    not is_official_client_url(page.url) or
                    WRITER_LEASE_PATH.exists()):
                raise RuntimeError("DOCUMENT_OR_WRITER_IDENTITY_CHANGED")
            observer_after = await read_controlled_document_observer_status(page)
            if observer_after != observer_before:
                raise RuntimeError("PRISTINE_OBSERVER_CHANGED")
            final_margin = _lease_margin_and_owner()
            if final_margin < MIN_END_LEASE_MS:
                raise RuntimeError("LEASE_CLEANUP_MARGIN_EXHAUSTED")

            if not all(row["handler_state_b_matches_fixed_adapter_0x13e700"]
                       for row in checked_rows):
                raise RuntimeError("FIXED_ADAPTER_ABI_MISMATCH")
            base["BEFORE"].update({
                "document_id": extractor.document_id,
                "time_origin_ms": float(origin_before),
                "route_class": route_class,
                "frame_identity_stable": True,
                "host_lease_margin_at_start_ms": lease_margin,
                "host_lease_margin_at_end_ms": final_margin,
                "pinned_client_attach_verified": True,
                "observer_pristine_before_and_after": True,
            })
            base["OBSERVED"] = {
                "status": "SANITIZED_METADATA_CAPTURED",
                "canvas_count": canvas_count,
                "matching_official_mouse_handlers": len(checked_rows),
                "handler_function_references_equal_before_after_scope_reads": True,
                "callbacks": checked_rows,
                "full_listener_topology_qualification": "NOT_ATTEMPTED",
                "inner_callback_vtable_binding": "UNKNOWN_NOT_READ",
                "raw_closure_refs_persisted": False,
                "world_state_sampled": False,
            }
            base["DIFF"] = (
                "Current canvas mouse handlers match the pinned generated mutable-closure "
                "wrapper ABI only if all three sanitized state.b comparisons matched 0x13e700. "
                "The inner callback pair is stored in a WASM listener envelope and was not read; "
                "no relation to candidate callback vtable 0x1137a8 is asserted."
            )
            base["VERDICT"] = "METADATA_DIAGNOSTIC_FIXED_ADAPTER_CONFIRMED_ZERO_FORMAL_CREDIT"
    except Exception as exc:
        base["OBSERVED"] = {
            "status": "FAIL_CLOSED",
            "failure_stage": stage,
            "failure_class": type(exc).__name__,
            "event_count": len(checked_rows),
            "callbacks": checked_rows,
            "failure_reason": str(exc) if isinstance(exc, RuntimeError) and str(exc).isupper() and len(str(exc)) < 120 else "UNPUBLISHED_EXCEPTION_DETAIL",
            "raw_closure_refs_persisted": False,
        }
        base["DIFF"] = "Metadata scope could not be safely established; inner callback vtable remains UNKNOWN."
        base["VERDICT"] = "METADATA_UNAVAILABLE_FAIL_CLOSED"
    finally:
        if extractor is not None and extractor.cdp is not None:
            cdp = extractor.cdp
            for object_id in object_ids:
                try:
                    await cdp.send("Runtime.releaseObject", {"objectId": object_id})
                except Exception:
                    pass
            try:
                await cdp.send("Runtime.releaseObjectGroup", {"objectGroup": object_group})
            except Exception:
                pass
            if debugger_enabled:
                try:
                    await cdp.send("Debugger.disable", {})
                except Exception:
                    pass
            try:
                await extractor.close()
            except Exception:
                pass
    return base


async def _entry() -> None:
    try:
        receipt = await asyncio.wait_for(_run(), timeout=TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        receipt = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
        receipt["OBSERVED"] = {"status": "FAIL_CLOSED", "failure_stage": "TIMEOUT",
                               "failure_class": "TimeoutError", "event_count": 0,
                               "raw_closure_refs_persisted": False}
        receipt["DIFF"] = "The metadata-only 30-second bound expired; inner callback vtable remains UNKNOWN."
        receipt["VERDICT"] = "METADATA_UNAVAILABLE_FAIL_CLOSED"
    _write_receipt(receipt)


if __name__ == "__main__":
    asyncio.run(_entry())
