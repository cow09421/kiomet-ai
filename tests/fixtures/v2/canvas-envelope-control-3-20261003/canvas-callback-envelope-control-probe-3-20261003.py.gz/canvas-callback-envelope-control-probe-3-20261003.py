"""Plan-only control-envelope probe for one current official canvas listener vtable word.

Do not run without separate authorization. Reads at most one u32 at state.a+4 per mouse event; never follows the Rc pointer at state.a, invokes a handler, or reads actor/game payload.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import sys
import time
import uuid
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import (
    CLIENT_SHA256,
    ClientExtractor,
    connect_dedicated,
    is_official_client_url,
)
from tools.v2_controlled_transition_capture import is_project_headless_browser_process
from tools.v2_headless_research import read_controlled_document_observer_status


PLAN_PATH = ROOT / "runtime/research/v2/canvas-callback-envelope-control-probe-3-plan-20261003.json"
OUTPUT_PATH = ROOT / "runtime/research/v2/canvas-callback-envelope-control-probe-3-20261003.json"
PROFILE_PATH = (ROOT / "runtime/browser-profile").resolve()
HOST_SCRIPT = (ROOT / "tools/v2_headless_research.py").resolve()
HOST_LEASE_PATH = ROOT / "runtime/research/v2/headless-host.json"
WRITER_LEASE_PATH = ROOT / "runtime/research/v2/controlled-transition-writer.json"
TIMEOUT_SECONDS = 30
MIN_INITIAL_LEASE_MS = 60_000
MIN_END_LEASE_MS = 60_000
GENERATED_JS_SHA256 = "05b51675785a3f6568f4d80562dabb4f59a6130504c7a04c7de9cf777c33094e"
LOCAL_SOURCE_PINS = {
    ROOT / "runtime/research/v2/fae13d1d0a7683726db520ec5c687d67d701c874a5708aeb9bff6eaacf2f054c.wasm": CLIENT_SHA256,
    ROOT / "runtime/research/v2/client.js": GENERATED_JS_SHA256,
    ROOT / "runtime/research/v2/listener-source-captures-20261002/05b51675785a3f6568f4d80562dabb4f59a6130504c7a04c7de9cf777c33094e.js": GENERATED_JS_SHA256,
}
OFFICIAL_LISTENER = (GENERATED_JS_SHA256, 2270, 17)
SHIM_SOURCE_LINE = 1975  # CDP zero-based; one-based client.js line 1976
SHIM_SOURCE_COLUMN = 125  # V8 StartPosition at the opening parenthesis; fail closed if browser differs
SHIM_FUNCTION_NAME = "wasm_bindgen_6b69409326653860___convert__closures_____invoke___wasm_bindgen_6b69409326653860___JsValue______true__1_"
SHIM_SOURCE_SHA256 = "5aeba66a72e652c4018f55df7416d851b55b50cfbf9e2f714887c243faecf06d"
CANDIDATE_INNER_VTABLE = 0x1137A8
ADAPTER_RECORD = 0x13E700
EVENTS = ("mousemove", "mousedown", "mouseup")
STATE_FIELDS = frozenset({"a", "b", "cnt", "dtor"})


def _lease_margin_and_owner() -> int:
    import psutil

    if not HOST_LEASE_PATH.is_file():
        raise RuntimeError("HOST_LEASE_MISSING")
    lease = json.loads(HOST_LEASE_PATH.read_text(encoding="utf-8"))
    if WRITER_LEASE_PATH.exists():
        raise RuntimeError("CONTROLLED_WRITER_ACTIVE")
    remaining = lease.get("deadline_monotonic_ms", 0) - time.monotonic_ns() // 1_000_000
    if (type(lease.get("pid")) is not int or lease["pid"] <= 0 or
            Path(lease.get("profile", "")).resolve() != PROFILE_PATH or
            remaining < MIN_INITIAL_LEASE_MS):
        raise RuntimeError("HOST_LEASE_OR_PROFILE_INVALID")
    try:
        process = psutil.Process(lease["pid"])
        args = process.cmdline()
        if (not process.name().lower().startswith(("python", "py")) or
                not any(Path(arg).resolve() == HOST_SCRIPT for arg in args
                        if arg.lower().endswith(".py"))):
            raise RuntimeError("HOST_PROCESS_MISMATCH")
        owners = []
        for child in process.children(recursive=True):
            try:
                if is_project_headless_browser_process(
                        child.name(), child.cmdline(), PROFILE_PATH):
                    owners.append(child.pid)
            except psutil.Error:
                continue
        if len(owners) != 1:
            raise RuntimeError("OWNED_CHROMIUM_COUNT_MISMATCH")
    except (psutil.Error, OSError) as exc:
        raise RuntimeError("HOST_PROCESS_UNVERIFIABLE") from exc
    return int(remaining)


async def _value(cdp: Any, expression: str) -> Any:
    response = await cdp.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": True,
        "awaitPromise": False,
        "userGesture": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("DOM_METADATA_EVALUATION_FAILED")
    remote = response.get("result") or {}
    if remote.get("subtype") == "error" or "value" not in remote:
        raise RuntimeError("DOM_METADATA_VALUE_UNAVAILABLE")
    return remote["value"]


async def _object(cdp: Any, expression: str, object_group: str) -> str:
    response = await cdp.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": False,
        "awaitPromise": False,
        "userGesture": False,
        "objectGroup": object_group,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("CANVAS_OBJECT_QUERY_FAILED")
    remote = response.get("result") or {}
    object_id = remote.get("objectId")
    if not isinstance(object_id, str) or not object_id:
        raise RuntimeError("CANVAS_OBJECT_ID_UNAVAILABLE")
    return object_id


async def _frame(cdp: Any) -> dict[str, Any]:
    response = await cdp.send("Page.getFrameTree", {})
    frame = (response.get("frameTree") or {}).get("frame")
    if not isinstance(frame, dict):
        raise RuntimeError("MAIN_FRAME_UNAVAILABLE")
    return {"frame_id": frame.get("id"), "loader_id": frame.get("loaderId"),
            "url": frame.get("url")}


async def _event_rows(cdp: Any, canvas_id: str) -> list[dict[str, Any]]:
    response = await cdp.send("DOMDebugger.getEventListeners", {
        "objectId": canvas_id,
        "depth": 0,
        "pierce": False,
    })
    rows = response.get("listeners")
    if not isinstance(rows, list):
        raise RuntimeError("CANVAS_LISTENER_ROWS_UNAVAILABLE")
    # Do not inspect other event types or any non-canvas DOM listener.
    selected = [row for row in rows if isinstance(row, dict) and row.get("type") in EVENTS]
    if len(selected) != len(EVENTS) or any(
            sum(row.get("type") == event for row in selected) != 1 for event in EVENTS):
        raise RuntimeError("OFFICIAL_CANVAS_MOUSE_LISTENER_SET_MISMATCH")
    return selected


async def _same_function_reference(cdp: Any, before_id: str, after_id: str) -> bool:
    if not isinstance(before_id, str) or not before_id or not isinstance(after_id, str) or not after_id:
        raise RuntimeError("HANDLER_REFERENCE_UNAVAILABLE_FOR_COMPARISON")
    response = await cdp.send("Runtime.callFunctionOn", {
        "objectId": before_id,
        "functionDeclaration": "function(other) { return this === other; }",
        "arguments": [{"objectId": after_id}],
        "returnByValue": True,
        "userGesture": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("HANDLER_REFERENCE_COMPARISON_FAILED")
    remote = response.get("result") or {}
    if remote.get("type") != "boolean" or not isinstance(remote.get("value"), bool):
        raise RuntimeError("HANDLER_REFERENCE_COMPARISON_MALFORMED")
    return remote["value"]


async def _same_handler_row(cdp: Any, before: dict[str, Any], after: dict[str, Any]) -> bool:
    if (before.get("type") != after.get("type") or
            before.get("useCapture") is not False or after.get("useCapture") is not False or
            before.get("scriptId") != after.get("scriptId") or
            (after.get("lineNumber"), after.get("columnNumber")) !=
            (OFFICIAL_LISTENER[1], OFFICIAL_LISTENER[2])):
        return False
    before_handler, after_handler = before.get("handler"), after.get("handler")
    if (not isinstance(before_handler, dict) or before_handler.get("type") != "function" or
            not isinstance(before_handler.get("objectId"), str) or not before_handler.get("objectId") or
            not isinstance(after_handler, dict) or after_handler.get("type") != "function" or
            not isinstance(after_handler.get("objectId"), str) or not after_handler.get("objectId")):
        return False
    script_id = after.get("scriptId")
    if not isinstance(script_id, str) or not script_id:
        return False
    source_response = await cdp.send("Debugger.getScriptSource", {"scriptId": script_id})
    source = source_response.get("scriptSource")
    if not isinstance(source, str) or hashlib.sha256(source.encode("utf-8")).hexdigest() != OFFICIAL_LISTENER[0]:
        return False
    return await _same_function_reference(cdp, before_handler["objectId"], after_handler["objectId"])


async def _properties(cdp: Any, object_id: str, *, own: bool) -> dict[str, Any]:
    response = await cdp.send("Runtime.getProperties", {
        "objectId": object_id,
        "ownProperties": own,
        "accessorPropertiesOnly": False,
        "generatePreview": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("SCOPE_PROPERTY_READ_FAILED")
    return response


def _remote_number(descriptor: dict[str, Any]) -> int | None:
    if descriptor.get("get") is not None or descriptor.get("set") is not None:
        return None
    value = descriptor.get("value")
    number = value.get("value") if isinstance(value, dict) else None
    if (not isinstance(value, dict) or value.get("type") != "number" or
            isinstance(number, bool) or not isinstance(number, (int, float)) or
            not math.isfinite(number) or int(number) != number):
        return None
    return int(number)


def _remote_string(descriptor: dict[str, Any]) -> str | None:
    if descriptor.get("get") is not None or descriptor.get("set") is not None:
        return None
    value = descriptor.get("value")
    raw = value.get("value") if isinstance(value, dict) else None
    if not isinstance(value, dict) or value.get("type") != "string" or not isinstance(raw, str):
        return None
    return raw


async def _authenticate_captured_shim(cdp: Any, shim_id: str, object_ids: set[str], progress: dict[str, Any]) -> None:
    if not isinstance(shim_id, str) or not shim_id:
        raise RuntimeError("CAPTURED_SHIM_OBJECT_UNAVAILABLE")
    # Runtime.getProperties returns function internals, including a [[Scopes]]
    # reference; consume only [[FunctionLocation]] and never follow [[Scopes]].
    props = await _properties(cdp, shim_id, own=False)
    locations = [p.get("value") for p in props.get("internalProperties", [])
                 if isinstance(p, dict) and p.get("name") == "[[FunctionLocation]]"]
    if len(locations) != 1 or not isinstance(locations[0], dict):
        raise RuntimeError("CAPTURED_SHIM_LOCATION_UNAVAILABLE_OR_AMBIGUOUS")
    location_remote = locations[0]
    source_id = None
    line = None
    column = None
    safe_types = {"object", "function", "undefined", "string", "number", "boolean"}
    safe_subtypes = {"internal#location", "null", "array", "error", "date", "regexp", "map", "set"}
    inline = location_remote.get("value")
    keys = sorted(k for k in inline if k in {"scriptId", "lineNumber", "columnNumber"}) if isinstance(inline, dict) else []
    exact_inline_shape = (location_remote.get("type") == "object" and
        location_remote.get("subtype") == "internal#location" and
        isinstance(inline, dict) and set(inline) == {"scriptId", "lineNumber", "columnNumber"} and
        isinstance(inline.get("scriptId"), str) and bool(inline.get("scriptId")) and
        type(inline.get("lineNumber")) is int and type(inline.get("columnNumber")) is int)
    progress["location_diagnostic"] = {
        "remote_type": location_remote.get("type") if location_remote.get("type") in safe_types else "OTHER",
        "remote_subtype": location_remote.get("subtype") if location_remote.get("subtype") in safe_subtypes else ("NONE" if "subtype" not in location_remote else "OTHER"),
        "inline_value_present": "value" in location_remote,
        "object_id_present": isinstance(location_remote.get("objectId"), str) and bool(location_remote.get("objectId")),
        "allowed_inline_keys_present": keys,
        "exact_inline_shape": exact_inline_shape,
        "script_id_string_nonempty": isinstance(inline, dict) and isinstance(inline.get("scriptId"), str) and bool(inline.get("scriptId")),
        "expected_line": isinstance(inline, dict) and type(inline.get("lineNumber")) is int and inline.get("lineNumber") == SHIM_SOURCE_LINE,
        "expected_column": isinstance(inline, dict) and type(inline.get("columnNumber")) is int and inline.get("columnNumber") == SHIM_SOURCE_COLUMN,
    }
    # V8 LocationMirror is a typed CDP RemoteObject. Its current supported
    # form is inline; retain a legacy objectId form only with the exact same
    # internal location subtype. Never fall back if malformed inline data exists.
    if location_remote.get("type") != "object" or location_remote.get("subtype") != "internal#location":
        raise RuntimeError("CAPTURED_SHIM_LOCATION_TYPE_MISMATCH")
    has_location_object_id = isinstance(location_remote.get("objectId"), str) and bool(location_remote.get("objectId"))
    if "value" in location_remote:
        if has_location_object_id or not exact_inline_shape:
            raise RuntimeError("CAPTURED_SHIM_LOCATION_INLINE_SHAPE_MISMATCH")
        source_id = inline["scriptId"]
        line = inline["lineNumber"]
        column = inline["columnNumber"]
    elif has_location_object_id:
        location_id = location_remote["objectId"]
        object_ids.add(location_id)
        location_props = await _properties(cdp, location_id, own=True)
        location_fields = {item.get("name"): item for item in location_props.get("result", [])
                           if isinstance(item, dict)}
        source_id = _remote_string(location_fields.get("scriptId", {}))
        line = _remote_number(location_fields.get("lineNumber", {}))
        column = _remote_number(location_fields.get("columnNumber", {}))
    else:
        raise RuntimeError("CAPTURED_SHIM_LOCATION_VALUE_UNAVAILABLE")
    if source_id is None or line != SHIM_SOURCE_LINE or column != SHIM_SOURCE_COLUMN:
        raise RuntimeError("CAPTURED_SHIM_LOCATION_PIN_MISMATCH")
    source_response = await cdp.send("Debugger.getScriptSource", {"scriptId": source_id})
    source = source_response.get("scriptSource")
    source_hash_matches = isinstance(source, str) and hashlib.sha256(source.encode("utf-8")).hexdigest() == GENERATED_JS_SHA256
    progress["location_diagnostic"]["pinned_source_hash_matches"] = source_hash_matches
    if not source_hash_matches:
        raise RuntimeError("CAPTURED_SHIM_SOURCE_HASH_MISMATCH")
    lines = source.splitlines(keepends=True)
    if SHIM_SOURCE_LINE + 3 > len(lines):
        raise RuntimeError("CAPTURED_SHIM_SOURCE_BODY_MISSING")
    shim_text = "".join(lines[SHIM_SOURCE_LINE:SHIM_SOURCE_LINE + 3])
    header = lines[SHIM_SOURCE_LINE].rstrip("\r\n")
    if (not header.startswith("function " + SHIM_FUNCTION_NAME + "(") or
            hashlib.sha256(shim_text.encode("utf-8")).hexdigest() != SHIM_SOURCE_SHA256):
        raise RuntimeError("CAPTURED_SHIM_SOURCE_BODY_MISMATCH")


async def _read_candidate_control_word(cdp: Any, memories_id: str, state_id: str, state_a: int) -> bool:
    if not isinstance(memories_id, str) or not memories_id:
        raise RuntimeError("OWNED_MEMORY_HANDLE_UNAVAILABLE")
    response = await cdp.send("Runtime.callFunctionOn", {
        "objectId": memories_id,
        "functionDeclaration": """function(address, state) {
          const list = this;
          if (!Array.isArray(list) || list.length !== 1) return {single_memory:false};
          const memory = list[0];
          if (!(memory instanceof WebAssembly.Memory)) return {single_memory:false};
          const buffer = memory.buffer;
          const shared = typeof SharedArrayBuffer === 'function' && buffer instanceof SharedArrayBuffer;
          const ordinary = buffer instanceof ArrayBuffer && !shared;
          const length = buffer.byteLength;
          const aligned = Number.isSafeInteger(address) && address > 0 && address <= 0xffffffff && address % 4 === 0;
          const inBounds = aligned && address <= length - 8;
          if (!ordinary || !inBounds) return {single_memory:true, ordinary_array_buffer:ordinary, shared_buffer:shared, aligned, in_bounds:inBounds};
          if (!state || typeof state !== 'object') return {single_memory:true, ordinary_array_buffer:true, shared_buffer:false, aligned:true, in_bounds:true, state_valid:false};
          const ad = Object.getOwnPropertyDescriptor(state, 'a');
          const bd = Object.getOwnPropertyDescriptor(state, 'b');
          const cd = Object.getOwnPropertyDescriptor(state, 'cnt');
          const dd = Object.getOwnPropertyDescriptor(state, 'dtor');
          const data = d => d && ('value' in d) && !('get' in d) && !('set' in d);
          const stateValid = data(ad) && data(bd) && data(cd) && !dd && Number.isInteger(ad.value) && ad.value === address && ad.value > 0 && ad.value % 4 === 0 && bd.value === 0x13e700 && Number.isInteger(cd.value) && cd.value >= 1;
          if (!stateValid) return {single_memory:true, ordinary_array_buffer:true, shared_buffer:false, aligned:true, in_bounds:true, state_valid:false};
          const actual = new DataView(buffer).getUint32(address + 4, true);
          return {single_memory:true, ordinary_array_buffer:true, shared_buffer:false, aligned:true, in_bounds:true, state_valid:true, candidate_matches:actual === 0x1137a8};
        }""",
        "arguments": [{"value": state_a}, {"objectId": state_id}],
        "returnByValue": True,
        "awaitPromise": False,
        "userGesture": False,
    })
    if response.get("exceptionDetails"):
        raise RuntimeError("CONTROL_ENVELOPE_READ_FAILED")
    result = response.get("result") or {}
    value = result.get("value")
    if (not isinstance(value, dict) or value.get("single_memory") is not True or
            value.get("ordinary_array_buffer") is not True or value.get("shared_buffer") is not False or
            value.get("aligned") is not True or value.get("in_bounds") is not True or
            value.get("state_valid") is not True or not isinstance(value.get("candidate_matches"), bool)):
        raise RuntimeError("CONTROL_ENVELOPE_MEMORY_OR_BOUNDS_INVALID")
    return value["candidate_matches"]


async def _read_state_scalars(cdp: Any, state_id: str) -> tuple[int, int, int]:
    props = await _properties(cdp, state_id, own=True)
    allowed = {p.get("name"): p for p in props.get("result", [])
               if isinstance(p, dict) and p.get("name") in STATE_FIELDS}
    if not {"a", "b", "cnt"}.issubset(allowed):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_FIELDS_INCOMPLETE")
    a = _remote_number(allowed["a"])
    b = _remote_number(allowed["b"])
    cnt = _remote_number(allowed["cnt"])
    if a is None or b is None or cnt is None or a <= 0 or b != ADAPTER_RECORD or cnt < 1 or "dtor" in allowed:
        raise RuntimeError("MUTABLE_CLOSURE_STATE_RECHECK_FAILED")
    return a, b, cnt


async def _inspect_one_handler(cdp: Any, row: dict[str, Any], object_ids: set[str], progress: dict[str, Any]) -> tuple[dict[str, Any], str, int]:
    event = row.get("type")
    script_id = row.get("scriptId")
    handler = row.get("handler")
    if (row.get("useCapture") is not False or
            not isinstance(script_id, str) or not script_id or
            (row.get("lineNumber"), row.get("columnNumber")) !=
            (OFFICIAL_LISTENER[1], OFFICIAL_LISTENER[2]) or
            not isinstance(handler, dict) or handler.get("type") != "function" or
            not isinstance(handler.get("objectId"), str)):
        raise RuntimeError("OFFICIAL_CANVAS_HANDLER_IDENTITY_MISMATCH")
    handler_id = handler["objectId"]
    object_ids.add(handler_id)

    script_response = await cdp.send("Debugger.getScriptSource", {
        "scriptId": script_id,
    })
    source = script_response.get("scriptSource")
    if not isinstance(source, str):
        raise RuntimeError("OFFICIAL_HANDLER_SOURCE_UNAVAILABLE")
    source_hash = hashlib.sha256(source.encode("utf-8")).hexdigest()
    if source_hash != OFFICIAL_LISTENER[0]:
        raise RuntimeError("OFFICIAL_HANDLER_SOURCE_HASH_MISMATCH")

    function_props = await _properties(cdp, handler_id, own=False)
    scopes = [p.get("value") for p in function_props.get("internalProperties", [])
              if isinstance(p, dict) and p.get("name") == "[[Scopes]]"]
    if len(scopes) != 1 or not isinstance(scopes[0], dict):
        raise RuntimeError("FUNCTION_SCOPES_UNAVAILABLE_OR_AMBIGUOUS")
    scopes_id = scopes[0].get("objectId")
    if not isinstance(scopes_id, str):
        raise RuntimeError("FUNCTION_SCOPE_LIST_ID_UNAVAILABLE")
    object_ids.add(scopes_id)

    # Enumerate only the scope-list array to select the function's Closure
    # scope. Never request properties from Script or Global scopes.
    scope_list = await _properties(cdp, scopes_id, own=True)
    scope_candidates = []
    for descriptor in scope_list.get("result", []):
        if not isinstance(descriptor, dict) or not str(descriptor.get("name", "")).isdigit():
            continue
        value = descriptor.get("value")
        if (isinstance(value, dict) and isinstance(value.get("description"), str) and
                value["description"].startswith("Closure") and
                isinstance(value.get("objectId"), str)):
            scope_candidates.append(value["objectId"])
    if len(scope_candidates) != 1:
        raise RuntimeError("CLOSURE_SCOPE_UNAVAILABLE_OR_AMBIGUOUS")
    closure_scope_id = scope_candidates[0]
    object_ids.add(closure_scope_id)

    # Request the closure scope once; consume only `state` and the captured
    # invocation shim `f`. No other binding is followed.
    closure_bindings = await _properties(cdp, closure_scope_id, own=True)
    state_descriptors = [p for p in closure_bindings.get("result", [])
                         if isinstance(p, dict) and p.get("name") == "state"]
    shim_descriptors = [p for p in closure_bindings.get("result", [])
                        if isinstance(p, dict) and p.get("name") == "f"]
    if len(state_descriptors) != 1:
        raise RuntimeError("MUTABLE_CLOSURE_STATE_BINDING_UNAVAILABLE")
    if len(shim_descriptors) != 1:
        raise RuntimeError("MUTABLE_CLOSURE_SHIM_BINDING_UNAVAILABLE")
    shim_remote = shim_descriptors[0].get("value")
    if not isinstance(shim_remote, dict) or shim_remote.get("type") != "function" or not isinstance(shim_remote.get("objectId"), str) or not shim_remote.get("objectId"):
        raise RuntimeError("MUTABLE_CLOSURE_SHIM_FUNCTION_UNAVAILABLE")
    shim_id = shim_remote["objectId"]
    object_ids.add(shim_id)
    await _authenticate_captured_shim(cdp, shim_id, object_ids, progress)
    state_remote = state_descriptors[0].get("value")
    if not isinstance(state_remote, dict) or not isinstance(state_remote.get("objectId"), str):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_OBJECT_UNAVAILABLE")
    state_id = state_remote["objectId"]
    object_ids.add(state_id)

    state_props = await _properties(cdp, state_id, own=True)
    allowed = {p.get("name"): p for p in state_props.get("result", [])
               if isinstance(p, dict) and p.get("name") in STATE_FIELDS}
    if not {"a", "b", "cnt"}.issubset(allowed):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_FIELDS_INCOMPLETE")
    a_value = _remote_number(allowed["a"])
    b_value = _remote_number(allowed["b"])
    count_value = _remote_number(allowed["cnt"])
    dtor_present = "dtor" in allowed
    if (a_value is None or b_value is None or count_value is None or
            a_value <= 0 or b_value != ADAPTER_RECORD or count_value < 1 or dtor_present):
        raise RuntimeError("MUTABLE_CLOSURE_STATE_SHAPE_MISMATCH")

    # Do not publish `a`, `b`, handler/scope object IDs, or any raw heap ref.
    # b is checked only against the fixed adapter record established by the
    # pinned JS + WASM source ABI; it is not the inner callback vtable.
    return ({
        "event": event,
        "source_sha256": source_hash,
        "source_location_matches": True,
        "bubble_listener": True,
        "handler_function_reference_rechecked": False,
        "handler_state_a_nonzero": True,
        "handler_state_b_matches_fixed_adapter_0x13e700": b_value == ADAPTER_RECORD,
        "handler_state_cnt_positive": True,
        "handler_state_dtor_absent": True,
        "captured_f_matches_pinned_shim": True,
        "envelope_memory_single_nonshared_bounds_ok": True,
        "inner_callback_vtable_matches_candidate_0x1137a8": False,
    }, state_id, a_value)


def _read_accounting(progress: dict[str, Any]) -> dict[str, Any]:
    started = progress.get("control_reads_started", 0)
    completed = progress.get("control_reads_completed", 0)
    inflight_or_unresolved = started > completed
    return {
        "control_word_reads_started": started,
        "completed_control_word_reads": completed,
        "control_memory_bytes_read": None if inflight_or_unresolved else completed * 4,
        "control_memory_bytes_read_status": "UNKNOWN_IN_FLIGHT_OR_UNRESOLVED" if inflight_or_unresolved else "EXACT",
        "maximum_possible_control_memory_bytes_read": min(12, started * 4),
    }


def _write_receipt(receipt: dict[str, Any]) -> None:
    OUTPUT_PATH.write_text(json.dumps(receipt, ensure_ascii=True, indent=2) + "\n",
                           encoding="utf-8")
    observed = receipt.get("OBSERVED")
    rows = observed.get("callbacks", []) if isinstance(observed, dict) else []
    print(json.dumps({
        "output": str(OUTPUT_PATH),
        "verdict": receipt.get("VERDICT"),
        "event_count": len(rows),
        "candidate_matches": sum(
            row.get("inner_callback_vtable_matches_candidate_0x1137a8") is True
            for row in rows if isinstance(row, dict)),
    }, ensure_ascii=True))


async def _run(progress: dict[str, Any]) -> dict[str, Any]:
    progress.setdefault("control_reads_started", 0)
    progress.setdefault("control_reads_completed", 0)
    progress.setdefault("rows", [])
    base = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    base["VERDICT"] = "METADATA_UNAVAILABLE_FAIL_CLOSED"
    base["OBSERVED"] = {"status": "INCOMPLETE"}
    stage = "LEASE_PREFLIGHT"
    extractor = None
    debugger_enabled = False
    object_ids: set[str] = set()
    checked_rows = []
    canvas_id = None
    object_group = "canvas-envelope-control-" + uuid.uuid4().hex
    ephemeral_states: dict[str, tuple[str, int]] = {}
    try:
        stage = "LOCAL_SOURCE_PIN_PREFLIGHT"
        for path, expected_sha256 in LOCAL_SOURCE_PINS.items():
            if (not path.is_file() or
                    hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
                raise RuntimeError("LOCAL_PINNED_SOURCE_HASH_MISMATCH")
        local_js_lines = (ROOT / "runtime/research/v2/client.js").read_text(encoding="utf-8").splitlines(keepends=True)
        if (SHIM_SOURCE_LINE + 3 > len(local_js_lines) or
                not local_js_lines[SHIM_SOURCE_LINE].startswith("function " + SHIM_FUNCTION_NAME + "(") or
                hashlib.sha256("".join(local_js_lines[SHIM_SOURCE_LINE:SHIM_SOURCE_LINE + 3]).encode("utf-8")).hexdigest() != SHIM_SOURCE_SHA256):
            raise RuntimeError("LOCAL_CAPTURED_SHIM_SOURCE_PIN_MISMATCH")

        lease_margin = _lease_margin_and_owner()
        async with async_playwright() as playwright:
            stage = "DEDICATED_BROWSER_ATTACH"
            browser = await connect_dedicated(playwright, ROOT)
            official_pages = [page for context in browser.contexts for page in context.pages
                              if is_official_client_url(page.url)]
            if len(official_pages) != 1:
                raise RuntimeError("OFFICIAL_PAGE_COUNT_MISMATCH")
            page = official_pages[0]
            if not is_official_client_url(page.url):
                raise RuntimeError("OFFICIAL_URL_REQUIRED")
            route_class = "ROOT" if page.url == "https://kiomet.com/" else "PARTY"

            stage = "PRISTINE_OBSERVER_PREFLIGHT"
            observer_before = await read_controlled_document_observer_status(page)

            stage = "PINNED_CLIENT_ATTACH"
            extractor = ClientExtractor(page)
            await extractor.attach()
            if extractor.cdp is None or extractor.time_origin is None:
                raise RuntimeError("PINNED_EXTRACTOR_ATTACH_INCOMPLETE")
            cdp = extractor.cdp
            frame_before = await _frame(cdp)
            origin_before = await _value(cdp, "performance.timeOrigin")
            if (frame_before.get("url") != page.url or
                    not isinstance(origin_before, (int, float)) or
                    isinstance(origin_before, bool) or
                    float(origin_before) != float(extractor.time_origin)):
                raise RuntimeError("INITIAL_DOCUMENT_IDENTITY_MISMATCH")

            stage = "CANVAS_DISCOVERY"
            canvas_count = await _value(cdp, "document.querySelectorAll('canvas').length")
            if type(canvas_count) is not int or canvas_count != 1:
                raise RuntimeError("CANVAS_COUNT_NOT_UNIQUE")
            canvas_id = await _object(cdp, "document.querySelector('canvas')", object_group)
            object_ids.add(canvas_id)

            stage = "OFFICIAL_CANVAS_LISTENER_LOOKUP"
            await cdp.send("Debugger.enable", {})
            debugger_enabled = True
            rows_before = await _event_rows(cdp, canvas_id)
            for event in EVENTS:
                row = next((item for item in rows_before if item.get("type") == event), None)
                if row is None:
                    raise RuntimeError("OFFICIAL_CANVAS_MOUSE_LISTENER_MISSING")
                public_row, state_id, state_a = await _inspect_one_handler(cdp, row, object_ids, progress)
                progress["control_reads_started"] += 1
                candidate_match = await _read_candidate_control_word(
                    cdp, extractor.memories_id, state_id, state_a)
                progress["control_reads_completed"] += 1
                public_row["inner_callback_vtable_matches_candidate_0x1137a8"] = candidate_match
                checked_rows.append(public_row)
                progress["rows"].append(public_row)
                ephemeral_states[event] = (state_id, state_a)

            stage = "HANDLER_LIVENESS_RECHECK"
            rows_after = await _event_rows(cdp, canvas_id)
            for event in EVENTS:
                before_row = next((item for item in rows_before if item.get("type") == event), None)
                after_row = next((item for item in rows_after if item.get("type") == event), None)
                if before_row is None or after_row is None:
                    raise RuntimeError("HANDLER_ROW_MISSING_DURING_RECHECK")
                if not await _same_handler_row(cdp, before_row, after_row):
                    raise RuntimeError("HANDLER_FUNCTION_REFERENCE_CHANGED_DURING_READ")
                checked = next((item for item in checked_rows if item.get("event") == event), None)
                if checked is None:
                    raise RuntimeError("SANITIZED_HANDLER_ROW_UNAVAILABLE")
                checked["handler_function_reference_rechecked"] = True
                state_id, original_a = ephemeral_states[event]
                final_a, final_b, final_cnt = await _read_state_scalars(cdp, state_id)
                if final_a != original_a:
                    raise RuntimeError("CLOSURE_STATE_ADDRESS_CHANGED_DURING_READ")

            stage = "FINAL_IDENTITY_CHECK"
            frame_after = await _frame(cdp)
            origin_after = await _value(cdp, "performance.timeOrigin")
            if (frame_before != frame_after or origin_before != origin_after or
                    frame_after.get("url") != page.url or
                    not is_official_client_url(page.url) or
                    WRITER_LEASE_PATH.exists()):
                raise RuntimeError("DOCUMENT_OR_WRITER_IDENTITY_CHANGED")
            observer_after = await read_controlled_document_observer_status(page)
            if observer_after != observer_before:
                raise RuntimeError("PRISTINE_OBSERVER_CHANGED")
            final_margin = _lease_margin_and_owner()
            if final_margin < MIN_END_LEASE_MS:
                raise RuntimeError("LEASE_CLEANUP_MARGIN_EXHAUSTED")

            if not all(row["handler_state_b_matches_fixed_adapter_0x13e700"]
                       for row in checked_rows):
                raise RuntimeError("FIXED_ADAPTER_ABI_MISMATCH")
            base["BEFORE"].update({
                "route_class": route_class,
                "frame_identity_stable": True,
                "host_lease_margin_at_start_ms": lease_margin,
                "host_lease_margin_at_end_ms": final_margin,
                "pinned_client_attach_verified": True,
                "observer_pristine_before_and_after": True,
            })
            base["OBSERVED"] = {
                "status": "SANITIZED_METADATA_CAPTURED",
                "canvas_count": canvas_count,
                "matching_official_mouse_handlers": len(checked_rows),
                "handler_function_references_equal_before_after_scope_reads": True,
                "state_a_unchanged_positive_adapter_and_count_rechecked": True,
                **_read_accounting(progress),
                "control_word_bytes_read_per_handler": 4,
                "callbacks": checked_rows,
                "full_listener_topology_qualification": "NOT_ATTEMPTED",
                "inner_callback_vtable_binding": "CANDIDATE_EQUALITY_BOOLEAN_ONLY",
                "raw_closure_refs_persisted": False,
                "world_state_sampled": False,
            }
            base["DIFF"] = (
                "Current canvas mouse handlers match the pinned generated mutable-closure "
                "wrapper ABI only if all three sanitized state.b comparisons matched 0x13e700. "
                "The only control memory read was one bounded u32 at envelope+4 per handler; "
                "the Rc pointer target and callback/application payload were never followed."
            )
            base["VERDICT"] = "CONTROL_ENVELOPE_CANDIDATE_COMPARISONS_COMPLETE_ZERO_FORMAL_CREDIT"
    except Exception as exc:
        base["OBSERVED"] = {
            "status": "FAIL_CLOSED",
            "failure_stage": stage,
            "failure_class": type(exc).__name__,
            "event_count": len(checked_rows),
            "callbacks": checked_rows,
            "failure_reason": str(exc) if isinstance(exc, RuntimeError) and str(exc).isupper() and len(str(exc)) < 120 else "UNPUBLISHED_EXCEPTION_DETAIL",
            "raw_closure_refs_persisted": False,
            "captured_shim_location_diagnostic": progress.get("location_diagnostic"),
            **_read_accounting(progress),
        }
        base["DIFF"] = "Control-envelope metadata could not be safely established; current inner callback vtable remains UNKNOWN."
        base["VERDICT"] = "METADATA_UNAVAILABLE_FAIL_CLOSED"
    finally:
        if extractor is not None and extractor.cdp is not None:
            cdp = extractor.cdp
            for object_id in object_ids:
                try:
                    await cdp.send("Runtime.releaseObject", {"objectId": object_id})
                except Exception:
                    pass
            try:
                await cdp.send("Runtime.releaseObjectGroup", {"objectGroup": object_group})
            except Exception:
                pass
            if debugger_enabled:
                try:
                    await cdp.send("Debugger.disable", {})
                except Exception:
                    pass
            try:
                await extractor.close()
            except Exception:
                pass
    return base


async def _entry() -> None:
    progress: dict[str, Any] = {"control_reads_started": 0, "control_reads_completed": 0, "rows": []}
    try:
        receipt = await asyncio.wait_for(_run(progress), timeout=TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        receipt = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
        receipt["OBSERVED"] = {"status": "FAIL_CLOSED_TIMEOUT", "failure_stage": "TIMEOUT",
            "failure_class": "TimeoutError", "event_count": len(progress["rows"]),
            "callbacks": progress["rows"], "raw_closure_refs_persisted": False,
            "captured_shim_location_diagnostic": progress.get("location_diagnostic"),
            **_read_accounting(progress)}
        receipt["DIFF"] = "The bounded probe expired; partial sanitized checks are retained, and any in-flight read count/bytes remain UNKNOWN within the 12-byte maximum."
        receipt["VERDICT"] = "METADATA_UNAVAILABLE_FAIL_CLOSED"
    _write_receipt(receipt)


if __name__ == "__main__":
    asyncio.run(_entry())
