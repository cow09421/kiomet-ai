"""Read-only scalar diagnostic for canvas listener identity mismatches.

PLAN ONLY unless the parent authorizes a finite owned-host run. This helper
never invokes listeners, reads scopes, calls application WASM, or reads WASM
memory. It records at most three mouse listener rows with sanitized metadata.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import math
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import CLIENT_SHA256, ClientExtractor, connect_dedicated, is_official_client_url
from tools.v2_controlled_transition_capture import is_project_headless_browser_process
from tools.v2_headless_research import read_controlled_document_observer_status

PLAN_PATH = ROOT / "runtime/research/v2/canvas-metadata-identity-diagnostic-run-plan-20261002.json"
OUTPUT_PATH = ROOT / "runtime/research/v2/canvas-metadata-identity-diagnostic-20261002.json"
PROFILE_PATH = (ROOT / "runtime/browser-profile").resolve()
HOST_SCRIPT = (ROOT / "tools/v2_headless_research.py").resolve()
HOST_LEASE_PATH = ROOT / "runtime/research/v2/headless-host.json"
WRITER_LEASE_PATH = ROOT / "runtime/research/v2/controlled-transition-writer.json"
TIMEOUT_SECONDS = 30
MIN_INITIAL_LEASE_MS = 60_000
MIN_END_LEASE_MS = 60_000
GENERATED_JS_SHA256 = "05b51675785a3f6568f4d80562dabb4f59a6130504c7a04c7de9cf777c33094e"
LOCAL_SOURCE_PINS = {
    ROOT / "runtime/research/v2/fae13d1d0a7683726db520ec5c687d67d701c874a5708aeb9bff6eaacf2f054c.wasm": CLIENT_SHA256,
    ROOT / "runtime/research/v2/client.js": GENERATED_JS_SHA256,
    ROOT / "runtime/research/v2/listener-source-captures-20261002/05b51675785a3f6568f4d80562dabb4f59a6130504c7a04c7de9cf777c33094e.js": GENERATED_JS_SHA256,
}
PINNED_LINE = 2270
PINNED_COLUMN = 17
EVENTS = ("mousemove", "mousedown", "mouseup")


def _lease_margin_and_owner() -> int:
    import psutil
    if not HOST_LEASE_PATH.is_file():
        raise RuntimeError("HOST_LEASE_MISSING")
    lease = json.loads(HOST_LEASE_PATH.read_text(encoding="utf-8"))
    if WRITER_LEASE_PATH.exists():
        raise RuntimeError("CONTROLLED_WRITER_ACTIVE")
    remaining = lease.get("deadline_monotonic_ms", 0) - time.monotonic_ns() // 1_000_000
    if (type(lease.get("pid")) is not int or lease["pid"] <= 0 or
            Path(lease.get("profile", "")).resolve() != PROFILE_PATH or
            remaining < MIN_INITIAL_LEASE_MS):
        raise RuntimeError("HOST_LEASE_OR_PROFILE_INVALID")
    try:
        process = psutil.Process(lease["pid"])
        args = process.cmdline()
        if (not process.name().lower().startswith(("python", "py")) or
                not any(Path(arg).resolve() == HOST_SCRIPT for arg in args if arg.lower().endswith(".py"))):
            raise RuntimeError("HOST_PROCESS_MISMATCH")
        owners = []
        for child in process.children(recursive=True):
            try:
                if is_project_headless_browser_process(child.name(), child.cmdline(), PROFILE_PATH):
                    owners.append(child.pid)
            except psutil.Error:
                continue
        if len(owners) != 1:
            raise RuntimeError("OWNED_CHROMIUM_COUNT_MISMATCH")
    except (psutil.Error, OSError) as exc:
        raise RuntimeError("HOST_PROCESS_UNVERIFIABLE") from exc
    return int(remaining)


async def _value(cdp: Any, expression: str) -> Any:
    response = await cdp.send("Runtime.evaluate", {"expression": expression, "returnByValue": True,
        "awaitPromise": False, "userGesture": False})
    if response.get("exceptionDetails"):
        raise RuntimeError("DOM_METADATA_EVALUATION_FAILED")
    remote = response.get("result") or {}
    if remote.get("subtype") == "error" or "value" not in remote:
        raise RuntimeError("DOM_METADATA_VALUE_UNAVAILABLE")
    return remote["value"]


async def _object(cdp: Any, expression: str) -> str:
    response = await cdp.send("Runtime.evaluate", {"expression": expression, "returnByValue": False,
        "awaitPromise": False, "userGesture": False})
    if response.get("exceptionDetails"):
        raise RuntimeError("CANVAS_OBJECT_QUERY_FAILED")
    object_id = (response.get("result") or {}).get("objectId")
    if not isinstance(object_id, str) or not object_id:
        raise RuntimeError("CANVAS_OBJECT_ID_UNAVAILABLE")
    return object_id


async def _frame(cdp: Any) -> dict[str, Any]:
    response = await cdp.send("Page.getFrameTree", {})
    frame = (response.get("frameTree") or {}).get("frame")
    if not isinstance(frame, dict):
        raise RuntimeError("MAIN_FRAME_UNAVAILABLE")
    # Keep identity values in memory only; receipts contain stability booleans.
    return {"id": frame.get("id"), "loader": frame.get("loaderId"), "url": frame.get("url")}


async def _event_rows(cdp: Any, canvas_id: str) -> list[dict[str, Any]]:
    response = await cdp.send("DOMDebugger.getEventListeners", {"objectId": canvas_id,
        "depth": 0, "pierce": False})
    rows = response.get("listeners")
    if not isinstance(rows, list):
        raise RuntimeError("CANVAS_LISTENER_ROWS_UNAVAILABLE")
    selected = [row for row in rows if isinstance(row, dict) and row.get("type") in EVENTS]
    if len(selected) > 3:
        raise RuntimeError("RELEVANT_LISTENER_ROW_CAP_EXCEEDED")
    return selected


def _scalar_number(value: Any) -> int | float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return None
    return value


def _remote_summary(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {"present": False, "type": "MISSING", "subtype": "MISSING",
                "class_name": "MISSING", "object_id_present": False}
    raw_type = value.get("type")
    safe_type = raw_type if raw_type in {"function", "object", "undefined", "string", "number", "boolean"} else "OTHER"
    raw_subtype = value.get("subtype")
    safe_subtype = raw_subtype if raw_subtype in {"array", "null", "error", "promise", "node", "regexp", "date", "map", "set", "weakmap", "weakset", "iterator", "generator", "proxy", "typedarray", "arraybuffer", "dataview", "webassemblymemory"} else ("NONE" if raw_subtype is None else "OTHER")
    raw_class = value.get("className")
    safe_class = "Function" if raw_class == "Function" else ("NONE" if raw_class is None else "OTHER")
    return {"present": True, "type": safe_type, "subtype": safe_subtype,
            "class_name": safe_class, "object_id_present": isinstance(value.get("objectId"), str) and bool(value.get("objectId"))}


def _row_predicates(row: dict[str, Any], event: str, source_sha256: str | None) -> dict[str, Any]:
    script_id = row.get("scriptId")
    handler = row.get("handler")
    line = _scalar_number(row.get("lineNumber"))
    column = _scalar_number(row.get("columnNumber"))
    handler_valid = isinstance(handler, dict) and handler.get("type") == "function"
    return {
        "event_type_matches": row.get("type") == event,
        "use_capture_is_exact_false": row.get("useCapture") is False,
        "script_id_is_nonempty_string": isinstance(script_id, str) and bool(script_id),
        "line_number_matches_2270": line == PINNED_LINE,
        "column_number_matches_17": column == PINNED_COLUMN,
        "handler_is_function": handler_valid,
        "handler_object_id_is_nonempty_string": isinstance(handler, dict) and isinstance(handler.get("objectId"), str) and bool(handler.get("objectId")),
        "source_hash_matches_pin": source_sha256 == GENERATED_JS_SHA256,
    }


def _safe_row(row: dict[str, Any], event: str, source_sha256: str | None) -> dict[str, Any]:
    handler = row.get("handler")
    original = row.get("originalHandler")
    script_id = row.get("scriptId")
    line = _scalar_number(row.get("lineNumber"))
    column = _scalar_number(row.get("columnNumber"))
    source_type = "STRING" if source_sha256 is not None else "UNAVAILABLE"
    return {
        "event": event,
        "use_capture": {"present": "useCapture" in row, "type": "BOOLEAN" if isinstance(row.get("useCapture"), bool) else ("MISSING" if "useCapture" not in row else "OTHER"), "value": row.get("useCapture") if isinstance(row.get("useCapture"), bool) else None},
        "script_id": {"type": "STRING" if isinstance(script_id, str) else ("MISSING" if "scriptId" not in row else "OTHER"), "nonempty": isinstance(script_id, str) and bool(script_id)},
        "location": {"line_type": "NUMBER" if line is not None else ("MISSING" if "lineNumber" not in row else "OTHER"), "line_number": line,
                      "column_type": "NUMBER" if column is not None else ("MISSING" if "columnNumber" not in row else "OTHER"), "column_number": column},
        "handler": _remote_summary(handler),
        "original_handler": {"present": "originalHandler" in row, "descriptor": _remote_summary(original)},
        "source": {"hash_checked": isinstance(source_sha256, str), "hash_matches_pin": source_sha256 == GENERATED_JS_SHA256, "value_type": source_type},
        "predicates": _row_predicates(row, event, source_sha256),
    }


async def _inspect_row(cdp: Any, row: dict[str, Any], event: str) -> tuple[dict[str, Any], tuple[Any, ...]]:
    script_id = row.get("scriptId")
    source_hash = None
    if isinstance(script_id, str) and script_id:
        try:
            response = await cdp.send("Debugger.getScriptSource", {"scriptId": script_id})
            source = response.get("scriptSource")
            if isinstance(source, str):
                source_hash = hashlib.sha256(source.encode("utf-8")).hexdigest()
        except Exception:
            source_hash = None
    sanitized = _safe_row(row, event, source_hash)
    handler = row.get("handler") if isinstance(row.get("handler"), dict) else {}
    # Only compare ephemeral identity inside this process. Never serialize IDs.
    identity = (script_id, row.get("lineNumber"), row.get("columnNumber"),
                handler.get("objectId"), row.get("useCapture"),
                (row.get("originalHandler") or {}).get("objectId") if isinstance(row.get("originalHandler"), dict) else None)
    return sanitized, identity


def _first_mismatch(rows: list[dict[str, Any]], counts: dict[str, int]) -> str | None:
    for event in EVENTS:
        if counts.get(event) != 1:
            return f"{event}:EVENT_MULTIPLICITY"
        item = next((r for r in rows if r.get("event") == event), None)
        if item is None:
            return f"{event}:ROW_MISSING"
        for name, passed in item["predicates"].items():
            if passed is not True:
                return f"{event}:{name.upper()}"
    return None


def _write(receipt: dict[str, Any]) -> None:
    OUTPUT_PATH.write_text(json.dumps(receipt, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT_PATH), "verdict": receipt.get("VERDICT"),
                      "first_mismatch": (receipt.get("OBSERVED") or {}).get("first_mismatch")}, ensure_ascii=True))


async def _run() -> dict[str, Any]:
    base = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    base["VERDICT"] = "DIAGNOSTIC_UNAVAILABLE_FAIL_CLOSED"
    base["OBSERVED"] = {"status": "INCOMPLETE", "rows": []}
    stage = "LOCAL_SOURCE_PIN_PREFLIGHT"
    extractor = None
    debugger_enabled = False
    canvas_id = None
    rows_out: list[dict[str, Any]] = []
    try:
        for path, expected in LOCAL_SOURCE_PINS.items():
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise RuntimeError("LOCAL_PINNED_SOURCE_HASH_MISMATCH")
        lease_start = _lease_margin_and_owner()
        async with async_playwright() as playwright:
            stage = "DEDICATED_BROWSER_ATTACH"
            browser = await connect_dedicated(playwright, ROOT)
            pages = [p for context in browser.contexts for p in context.pages if is_official_client_url(p.url)]
            if len(pages) != 1:
                raise RuntimeError("OFFICIAL_PAGE_COUNT_MISMATCH")
            page = pages[0]
            route_class = "ROOT" if page.url == "https://kiomet.com/" else "PARTY"
            stage = "PRISTINE_OBSERVER_PREFLIGHT"
            observer_before = await read_controlled_document_observer_status(page)
            stage = "PINNED_CLIENT_ATTACH"
            extractor = ClientExtractor(page)
            await extractor.attach()
            if extractor.cdp is None or extractor.time_origin is None:
                raise RuntimeError("PINNED_EXTRACTOR_ATTACH_INCOMPLETE")
            cdp = extractor.cdp
            frame_before = await _frame(cdp)
            origin_before = await _value(cdp, "performance.timeOrigin")
            if (frame_before.get("url") != page.url or not isinstance(origin_before, (int, float)) or
                    isinstance(origin_before, bool) or float(origin_before) != float(extractor.time_origin)):
                raise RuntimeError("INITIAL_DOCUMENT_IDENTITY_MISMATCH")
            stage = "CANVAS_DISCOVERY"
            canvas_count = await _value(cdp, "document.querySelectorAll('canvas').length")
            if type(canvas_count) is not int or canvas_count != 1:
                raise RuntimeError("CANVAS_COUNT_NOT_UNIQUE")
            canvas_id = await _object(cdp, "document.querySelector('canvas')")
            stage = "OFFICIAL_CANVAS_LISTENER_LOOKUP"
            await cdp.send("Debugger.enable", {})
            debugger_enabled = True
            raw_rows = await _event_rows(cdp, canvas_id)
            counts = {event: sum(1 for row in raw_rows if row.get("type") == event) for event in EVENTS}
            identities_before = {}
            for event in EVENTS:
                row = next((r for r in raw_rows if r.get("type") == event), None)
                if row is None:
                    continue
                sanitized, identity = await _inspect_row(cdp, row, event)
                rows_out.append(sanitized)
                identities_before[event] = identity
            first = _first_mismatch(rows_out, counts)
            if first is None:
                stage = "HANDLER_ROW_STABILITY_RECHECK"
                after_rows = await _event_rows(cdp, canvas_id)
                after_counts = {event: sum(1 for row in after_rows if row.get("type") == event) for event in EVENTS}
                stable = counts == after_counts
                for event in EVENTS:
                    after = next((r for r in after_rows if r.get("type") == event), None)
                    if after is None:
                        stable = False
                        continue
                    _, identity_after = await _inspect_row(cdp, after, event)
                    stable = stable and identities_before.get(event) == identity_after
                if not stable:
                    first = "HANDLER_ROW_IDENTITY_CHANGED"
            stage = "FINAL_DOCUMENT_AND_OBSERVER_CHECK"
            frame_after = await _frame(cdp)
            origin_after = await _value(cdp, "performance.timeOrigin")
            if (frame_before != frame_after or origin_before != origin_after or frame_after.get("url") != page.url or
                    not is_official_client_url(page.url) or WRITER_LEASE_PATH.exists()):
                raise RuntimeError("DOCUMENT_OR_WRITER_IDENTITY_CHANGED")
            observer_after = await read_controlled_document_observer_status(page)
            if observer_after != observer_before:
                raise RuntimeError("PRISTINE_OBSERVER_CHANGED")
            lease_end = _lease_margin_and_owner()
            if lease_end < MIN_END_LEASE_MS:
                raise RuntimeError("LEASE_CLEANUP_MARGIN_EXHAUSTED")
            base["BEFORE"].update({"status": "RUN_COMPLETED", "route_class": route_class,
                "host_lease_margin_at_start_ms": lease_start, "host_lease_margin_at_end_ms": lease_end,
                "document_identity_stable": True, "observer_pristine_before_and_after": True})
            base["OBSERVED"] = {"status": "SANITIZED_ROW_DIAGNOSTIC_CAPTURED", "canvas_count": canvas_count,
                "selected_row_count": len(rows_out), "event_multiplicity": counts, "rows": rows_out,
                "first_mismatch": first, "scope_reads": 0, "handler_invocations": 0,
                "raw_object_ids_persisted": False}
            base["DIFF"] = "Listener-row identity diagnosis only; no closure scope or callback binding was inspected."
            base["VERDICT"] = "IDENTITY_PREDICATES_MATCH_DIAGNOSTIC_ONLY_ZERO_FORMAL_CREDIT" if first is None else "IDENTITY_MISMATCH_ISOLATED_DIAGNOSTIC_ONLY_ZERO_FORMAL_CREDIT"
    except Exception as exc:
        base["OBSERVED"] = {"status": "FAIL_CLOSED", "failure_stage": stage,
            "failure_class": type(exc).__name__, "failure_reason": str(exc) if isinstance(exc, RuntimeError) and str(exc).isupper() and len(str(exc)) < 120 else "UNPUBLISHED_EXCEPTION_DETAIL",
            "selected_row_count": len(rows_out), "rows": rows_out, "scope_reads": 0,
            "handler_invocations": 0, "raw_object_ids_persisted": False}
        base["DIFF"] = "Identity diagnosis did not complete; no scope or callback evidence was obtained."
        base["VERDICT"] = "DIAGNOSTIC_UNAVAILABLE_FAIL_CLOSED"
    finally:
        if extractor is not None and extractor.cdp is not None:
            cdp = extractor.cdp
            if canvas_id:
                try:
                    await cdp.send("Runtime.releaseObject", {"objectId": canvas_id})
                except Exception:
                    pass
            if debugger_enabled:
                try:
                    await cdp.send("Debugger.disable", {})
                except Exception:
                    pass
            try:
                await extractor.close()
            except Exception:
                pass
    return base


async def _entry() -> None:
    try:
        receipt = await asyncio.wait_for(_run(), timeout=TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        receipt = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
        receipt["OBSERVED"] = {"status": "FAIL_CLOSED", "failure_stage": "TIMEOUT",
            "failure_class": "TimeoutError", "selected_row_count": 0, "rows": [],
            "scope_reads": 0, "raw_object_ids_persisted": False}
        receipt["DIFF"] = "The bounded scalar diagnostic expired before identity predicates were established."
        receipt["VERDICT"] = "DIAGNOSTIC_UNAVAILABLE_FAIL_CLOSED"
    _write(receipt)


if __name__ == "__main__":
    asyncio.run(_entry())

