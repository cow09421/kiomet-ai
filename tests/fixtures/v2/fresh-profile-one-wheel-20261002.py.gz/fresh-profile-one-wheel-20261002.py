import asyncio,json,sys,time,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import ClientExtractor,connect_dedicated
from tools.v2_controlled_transition_capture import _sample_ready,state_json,control_readiness_gaps
spec=importlib.util.spec_from_file_location('friendly_preview',ROOT/'runtime/research/v2/friendly-fast-preview-20261002.py')
preview=importlib.util.module_from_spec(spec);spec.loader.exec_module(preview)
async def main():
    out=ROOT/'runtime/research/v2';path=out/'fresh-profile-one-wheel-20261002.json'
    receipt={'QUESTION':'Does one ordinary zoom-out reveal missing visible-force endpoints in the fresh owned profile?',
      'ACTION':{'wheel_limit':1,'wheel_attempted':False,'wheel_completed':False,'delta_y':240,'observer_arms':0,'troop_gestures':0},
      'OBSERVED':[],'errors':[],'formal_credit':0,'VERDICT':'PENDING'}
    ex=None
    try:
      lease,margin=await preview._owned_headless_lease(out)
      receipt['lease_margin_ms']=margin
      async with async_playwright() as pw:
        browser=await connect_dedicated(pw,ROOT)
        pages=[p for c in browser.contexts for p in c.pages if p.url=='https://kiomet.com/']
        if len(pages)!=1:raise ValueError('exactly one owned official page required')
        page=pages[0];ex=ClientExtractor(page);await ex.attach()
        state,raw=await _sample_ready(ex)
        if state.lifecycle.value!='IN_MATCH' or state.source_mode.value!='NETWORK':raise ValueError('normal network match unavailable')
        origin=raw.get('document_time_origin');scope=(state.document_id,state.match_id.value,state.player_id.value,origin)
        receipt['BEFORE']={'state':state,'camera':raw.get('camera_candidate'),'gaps':control_readiness_gaps(state,time.monotonic_ns()//1000000)}
        view=await page.evaluate("""()=>{const c=document.querySelector('canvas'),r=c?.getBoundingClientRect();const o=window[Symbol.for('kiomet.inputEntryObserver.v1')];return {canvas:r?{x:r.left+r.width/2,y:r.top+r.height/2,left:r.left,top:r.top,dpr:devicePixelRatio}:null,observer:o?.status(),editable:!!document.activeElement?.matches('input,textarea,[contenteditable=true]')}}""")
        r=view.get('canvas');obs=view.get('observer')
        if not r or r['left']!=0 or r['top']!=0 or r['dpr']!=1 or view['editable']:raise ValueError('ordinary full canvas target rejected')
        if not obs or obs.get('status')!='DISARMED' or obs.get('armed_once')is not False:raise ValueError('wheel must precede observer arming')
        hit=await page.evaluate('([x,y])=>document.elementFromPoint(x,y)===document.querySelector("canvas")',[r['x'],r['y']])
        if hit is not True:raise ValueError('canvas center is obstructed')
        receipt['canvas']=r;receipt['observer_before']=obs
        with path.open('x',encoding='utf8') as f:json.dump(receipt,f,default=state_json,indent=2)
        await page.mouse.move(r['x'],r['y'])
        receipt['ACTION']['wheel_attempted']=True
        await page.mouse.wheel(0,240)
        receipt['ACTION']['wheel_completed']=True
        deadline=time.monotonic()+4
        while time.monotonic()<deadline:
          await asyncio.sleep(.1)
          try:
            state,raw=await _sample_ready(ex)
            if (state.document_id,state.match_id.value,state.player_id.value,raw.get('document_time_origin'))!=scope:raise RuntimeError('document/match/player continuity changed')
            receipt['OBSERVED'].append({'state':state,'camera':raw.get('camera_candidate'),'positive_refs':raw.get('positive_refs'),'decoded_towers':len(raw.get('towers',[])),'gaps':control_readiness_gaps(state,time.monotonic_ns()//1000000)})
          except ValueError as exc:receipt['errors'].append(str(exc))
        receipt['observer_after']=await page.evaluate('window[Symbol.for("kiomet.inputEntryObserver.v1")].status()')
        receipt['SIMULATED']='No troop gesture; viewport/endpoint availability comparison only'
        receipt['DIFF']='Retain every observed force endpoint field and full canonical visible state; absence remains UNKNOWN'
        receipt['VERDICT']='READONLY_WORLD_VIEWPORT_DIAGNOSTIC_ZERO_CREDIT'
    except BaseException as exc:
      receipt['errors'].append(type(exc).__name__+': '+str(exc));receipt['VERDICT']='PARTIAL_OR_REJECTED_ZERO_CREDIT'
      if isinstance(exc,(asyncio.CancelledError,KeyboardInterrupt)):raise
    finally:
      if ex:
        try:await asyncio.wait_for(ex.close(),timeout=2)
        except Exception as exc:receipt['errors'].append('cleanup: '+str(exc))
      path.write_text(json.dumps(receipt,default=state_json,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
      print(json.dumps({'file':str(path.relative_to(ROOT)),'action':receipt['ACTION'],'errors':receipt['errors'],'before_gaps':receipt.get('BEFORE',{}).get('gaps'),'after_gaps':receipt['OBSERVED'][-1]['gaps'] if receipt['OBSERVED'] else None,'after_towers':receipt['OBSERVED'][-1]['decoded_towers'] if receipt['OBSERVED'] else None,'samples':len(receipt['OBSERVED']),'verdict':receipt['VERDICT']}),flush=True)
asyncio.run(asyncio.wait_for(main(),timeout=15))
