"""Fast, read-only preview of ordinary friendly and empty-neutral Soldier pairs.

This connects only to an already-running project-owned headless browser. It
does not start a host, select a tower, arm the observer, or dispatch input.
"""
from __future__ import annotations

import argparse
import asyncio
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
import traceback
from uuid import uuid4

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import ClientExtractor, connect_dedicated
from kiomet_ai.v2.state import Knowledge, Relation
from kiomet_ai.camera import world_to_page
from tools.v2_controlled_transition_capture import (
    _counts,
    _sample_ready,
    _preflight_snapshot_metadata,
    control_readiness_gaps,
    is_project_headless_browser_process,
    state_json,
    validate_scenario,
)

TANK, SOLDIER, SHIELD, RULER = 4, 5, 0, 9
PREVIEW_TIMEOUT_SECONDS = 15
MIN_HOST_MARGIN_MS = 30_000


def _fact(fact):
    return {
        "value": fact.value,
        "knowledge": getattr(fact.knowledge, "value", str(fact.knowledge)),
        "source": fact.source,
        "observed_at_ms": fact.observed_at_ms,
    }


def _tower_row(tower):
    names = (
        "owner", "relation", "tower_type", "units", "deployable", "capacity",
        "production", "neighbors", "position", "effects", "delay_ticks",
        "supply_line_present",
    )
    return {name: _fact(getattr(tower, name)) for name in names}


def _fact_is_observed(fact, value):
    return (fact.knowledge is Knowledge.OBSERVED and
            type(fact.value) is type(value) and fact.value == value)


def _observed_morale_boost(fact):
    """Return the cached aura only when the exact observed Boolean is present."""
    if fact.knowledge is not Knowledge.OBSERVED or not isinstance(fact.value, tuple):
        return None
    try:
        effects = dict(fact.value)
    except (TypeError, ValueError):
        return None
    value = effects.get("MORALE_BOOST")
    return value if type(value) is bool else None


def _unit_count(fact, unit):
    counts = _counts(fact)
    return None if counts is None else counts.get(unit, 0)


def _visible_inbound(force_list, destination_id):
    return [force for force in force_list
            if force.destination.value == destination_id]


def _candidate(state, source, destination, scenario, typed, boost,
               source_point, destination_point, inbound, checked):
    return {
        "scenario": scenario,
        "scenario_class": checked["scenario_class"],
        "scenario_ineligible_reasons": list(checked["scenario_ineligible_reasons"]),
        "source_id": source.id,
        "destination_id": destination.id,
        "source": _tower_row(source),
        "destination": _tower_row(destination),
        "all_current_deployable_baseline": [[kind, count] for kind, count in typed],
        "manual_force_accelerated_expected_from_observed_source_morale": boost,
        "visible_inbound_to_destination": [state_json(force) for force in inbound],
        "projected_source_center": list(source_point),
        "projected_destination_center": list(destination_point),
        "route_qualification": "UNKNOWN_UNTIL_HANDLER_BINDING_AND_RELEASE_REVIEW",
        "gesture_continuity": "UNKNOWN",
        "use": "candidate for parent review only; not an intent or authorization to send",
    }


def _reason(kind, source=None, destination=None, detail=None):
    row = {"kind": kind}
    if source is not None:
        row["source_id"] = source
    if destination is not None:
        row["destination_id"] = destination
    if detail is not None:
        row["detail"] = detail
    return row


def _enumerate_pairs(state, raw, view):
    candidates, refusals = [], []
    if state.coverage != "PLAYER_VISIBLE_COMPLETE" or state.forces.value is None:
        return candidates, [_reason("visible_world_not_complete",
                                    detail={"coverage": state.coverage})]
    readiness = control_readiness_gaps(state, time.monotonic_ns() // 1_000_000)
    if readiness:
        return candidates, [_reason("control_readiness_gaps", detail=list(readiness))]
    if raw.get("selected_tower", "__MISSING__") is not None:
        return candidates, [_reason("selection_not_explicitly_none",
                                    detail=raw.get("selected_tower", "__MISSING__"))]
    if (not isinstance(view, dict) or view.get("dpr") != 1 or
            view.get("left") != 0 or view.get("top") != 0 or
            not all(type(view.get(key)) in (int, float)
                    for key in ("w", "h", "cw", "ch"))):
        return candidates, [_reason("unsupported_canvas_geometry", detail=view)]
    camera = raw.get("camera_candidate")
    if not isinstance(camera, (tuple, list)) or len(camera) != 3:
        return candidates, [_reason("camera_candidate_unknown")]

    player = state.player_id.value
    towers = {tower.id: tower for tower in state.towers}
    forces = state.forces.value or ()
    for source in state.towers:
        if source.owner.value != player or source.relation.value != Relation.SELF:
            continue
        typed = source.deployable.value
        if typed is None:
            refusals.append(_reason("source_deployable_unknown", source.id))
            continue
        typed = tuple(sorted((kind, amount) for kind, amount in typed.counts if amount))
        if len(typed) != 1 or typed[0][0] != SOLDIER or typed[0][1] <= 0:
            refusals.append(_reason("source_not_soldier_only", source.id,
                                    detail=[[k, n] for k, n in typed]))
            continue
        source_units = _counts(source.units)
        source_capacity = _counts(source.capacity)
        if source_units is None or source_capacity is None:
            refusals.append(_reason("source_units_or_capacity_unknown", source.id))
            continue
        if source_units.get(RULER, 0) or source_units.get(SHIELD, 0) > source_capacity.get(SHIELD, 0):
            refusals.append(_reason("source_has_ruler_or_shield_overcapacity", source.id))
            continue
        source_boost = _observed_morale_boost(source.effects)
        if source_boost is not False:
            refusals.append(_reason("source_cached_morale_not_observed_false", source.id,
                                    detail=_fact(source.effects)))
            continue
        if not _fact_is_observed(source.supply_line_present, False):
            refusals.append(_reason("source_supply_line_not_observed_false", source.id,
                                    detail=_fact(source.supply_line_present)))
            continue
        if (source.delay_ticks.knowledge is not Knowledge.OBSERVED or
                type(source.delay_ticks.value) is not int or source.delay_ticks.value != 0):
            refusals.append(_reason("source_delay_not_known_zero", source.id,
                                    detail=_fact(source.delay_ticks)))
            continue
        neighbors = source.neighbors.value
        if neighbors is None:
            refusals.append(_reason("source_neighbors_unknown", source.id))
            continue

        for destination_id in neighbors:
            destination = towers.get(destination_id)
            if destination is None:
                refusals.append(_reason("adjacent_destination_not_visible", source.id,
                                        destination_id))
                continue
            if _unit_count(destination.units, RULER) is None:
                refusals.append(_reason("destination_units_unknown", source.id,
                                        destination_id))
                continue
            dest_units = _counts(destination.units)
            dest_capacity = _counts(destination.capacity)
            if dest_units is None or dest_capacity is None:
                refusals.append(_reason("destination_units_or_capacity_unknown", source.id,
                                        destination_id))
                continue
            if dest_units.get(RULER, 0):
                refusals.append(_reason("destination_contains_ruler", source.id,
                                        destination_id))
                continue
            if dest_units.get(SHIELD, 0) > dest_capacity.get(SHIELD, 0):
                refusals.append(_reason("destination_shield_overcapacity", source.id,
                                        destination_id,
                                        {"shield_units": dest_units.get(SHIELD, 0),
                                         "shield_capacity": dest_capacity.get(SHIELD, 0)}))
                continue
            if _observed_morale_boost(destination.effects) is None:
                refusals.append(_reason("destination_cached_morale_unknown", source.id,
                                        destination_id, _fact(destination.effects)))
                continue
            inbound = _visible_inbound(forces, destination_id)
            if inbound:
                refusals.append(_reason("visible_inbound_already_targets_destination", source.id,
                                        destination_id,
                                        [f.id.value for f in inbound]))
                continue

            checked = validate_scenario(state, source.id, destination_id)
            if isinstance(checked, str):
                refusals.append(_reason("scenario_guard", source.id, destination_id, checked))
                continue
            if destination.relation.value == Relation.SELF:
                if destination.owner.value != player:
                    refusals.append(_reason("friendly_destination_owner_unknown", source.id,
                                            destination_id))
                    continue
                if not _fact_is_observed(destination.supply_line_present, False):
                    refusals.append(_reason("friendly_destination_supply_line_not_observed_false",
                                            source.id, destination_id,
                                            _fact(destination.supply_line_present)))
                    continue
            elif destination.relation.value == Relation.NEUTRAL:
                if destination.owner.value != 0 or any(dest_units.values()):
                    refusals.append(_reason("neutral_destination_not_observed_empty", source.id,
                                            destination_id))
                    continue
            else:
                refusals.append(_reason("destination_relation_unsupported", source.id,
                                        destination_id,
                                        getattr(destination.relation.value, "value", None)))
                continue

            try:
                source_point = world_to_page(*source.position.value, *camera,
                                             view["w"], view["h"], 1)
                destination_point = world_to_page(*destination.position.value, *camera,
                                                  view["w"], view["h"], 1)
            except (TypeError, ValueError, ZeroDivisionError):
                refusals.append(_reason("endpoint_projection_failed", source.id,
                                        destination_id))
                continue
            safe = lambda x, y: 80 < x < view["cw"] - 160 and 90 < y < view["ch"] - 110
            if not (safe(*source_point) and safe(*destination_point)):
                refusals.append(_reason("endpoint_outside_safe_canvas", source.id,
                                        destination_id,
                                        {"source": source_point,
                                         "destination": destination_point}))
                continue
            candidates.append(_candidate(state, source, destination,
                "friendly_reinforcement" if destination.relation.value is Relation.SELF
                else "neutral_capture_preparation", typed, source_boost,
                source_point, destination_point, inbound, checked))
    candidates.sort(key=lambda row: (row["scenario"], row["source_id"], row["destination_id"]))
    return candidates, refusals


async def _owned_headless_lease(out):
    lease_path = out / "headless-host.json"
    if not lease_path.is_file():
        raise RuntimeError("owned headless host lease is absent; preview will not start a host")
    lease = json.loads(lease_path.read_text(encoding="utf-8"))
    profile = (ROOT / "runtime/browser-profile").resolve()
    remaining_ms = lease.get("deadline_monotonic_ms", 0) - time.monotonic_ns() // 1_000_000
    if (type(lease.get("pid")) is not int or lease["pid"] <= 0 or
            Path(lease.get("profile", "")).resolve() != profile or
            remaining_ms < MIN_HOST_MARGIN_MS):
        raise RuntimeError(f"owned host lease/profile rejected; remaining_ms={remaining_ms}")
    import psutil
    host = psutil.Process(lease["pid"])
    host_script = (ROOT / "tools/v2_headless_research.py").resolve()
    host_args = host.cmdline()
    if (not host.name().lower().startswith(("python", "py")) or
            not any(Path(arg).resolve() == host_script
                    for arg in host_args if arg.lower().endswith(".py"))):
        raise RuntimeError(f"host lease PID is not the project-owned headless process; remaining_ms={remaining_ms}")
    browser_owners = []
    for child in host.children(recursive=True):
        try:
            if is_project_headless_browser_process(child.name(), child.cmdline(), profile):
                browser_owners.append(child.pid)
        except psutil.Error:
            continue
    if len(browser_owners) != 1:
        raise RuntimeError(f"expected one owned Chromium child; found={len(browser_owners)} remaining_ms={remaining_ms}")
    return lease, remaining_ms


async def _run(output_path):
    out = ROOT / "runtime/research/v2"
    receipt = {
        "kind": "FRIENDLY_FAST_PURE_BEFORE_PREVIEW",
        "status": "REJECTED_BEFORE_CONNECT",
        "input_sent": False,
        "observer_armed": False,
        "wheel_events": 0,
        "troop_gestures": 0,
        "route_qualification": "UNKNOWN_UNTIL_HANDLER_BINDING_AND_RELEASE_REVIEW",
        "formal_credit": 0,
        "trajectory_credit": 0,
        "host_margin_required_ms": MIN_HOST_MARGIN_MS,
        "candidates": [],
        "guard_refusals": [],
    }
    browser = ex = None
    try:
        lease, remaining = await _owned_headless_lease(out)
        receipt["host_lease"] = {
            "pid": lease["pid"], "deadline_monotonic_ms": lease["deadline_monotonic_ms"],
            "remaining_ms_at_connect": remaining,
            "observer_requested_at_startup": bool(
                lease.get("input_entry_observer", {}).get("observer_requested")),
            "observer_registered_before_page": lease.get("input_entry_observer", {}).get(
                "registered_before_controlled_page_creation"),
        }
        async with async_playwright() as pw:
            browser = await connect_dedicated(pw, ROOT)
            pages = [page for context in browser.contexts for page in context.pages
                     if page.url == "https://kiomet.com/"]
            if len(pages) != 1:
                raise RuntimeError(f"expected exactly one owned official page; found={len(pages)}")
            page = pages[0]
            ex = ClientExtractor(page)
            await ex.attach()
            state, raw = await _sample_ready(ex)
            receipt["snapshot_metadata"] = _preflight_snapshot_metadata(state)
            receipt["client_sha256"] = state.client_sha256
            receipt["snapshot"] = state
            receipt["selection"] = {
                "key_present": isinstance(raw, dict) and "selected_tower" in raw,
                "selected_tower": raw.get("selected_tower") if isinstance(raw, dict) else None,
            }
            receipt["decoder_summary"] = {
                "tower_count": len(state.towers),
                "force_count": len(state.forces.value or ()) if state.forces.value is not None else None,
                "coverage": state.coverage,
                "coverage_evidence": state.coverage_evidence,
            }
            receipt["dom_metadata"] = await page.evaluate("""() => {
              const c=document.querySelector('canvas'), r=c?.getBoundingClientRect();
              const v=window.visualViewport;
              return {url_origin:location.origin, url_path:location.pathname, title:document.title,
                ready_state:document.readyState, visibility_state:document.visibilityState,
                has_focus:document.hasFocus(), canvas:c&&r?{bitmap_width:c.width,bitmap_height:c.height,
                left:r.left,top:r.top,width:r.width,height:r.height,dpr:devicePixelRatio,
                w:innerWidth,h:innerHeight,cw:r.width,ch:r.height}:null,
                visual_viewport:v?{scale:v.scale,offset_left:v.offsetLeft,offset_top:v.offsetTop,
                  width:v.width,height:v.height}:null,
                visible_headings:[...document.querySelectorAll('h1,h2')].filter(e=>e.getClientRects().length)
                  .map(e=>e.innerText.trim())};
            }""")
            view = receipt["dom_metadata"]["canvas"]
            if view is None:
                receipt["guard_refusals"].append(_reason("canvas_missing"))
            else:
                candidates, refusals = _enumerate_pairs(state, raw, view)
                receipt["candidates"] = candidates
                receipt["guard_refusals"].extend(refusals)
                if candidates:
                    points = [[row["projected_source_center"],
                               row["projected_destination_center"]] for row in candidates]
                    hits = await page.evaluate("""points => {
                      const c=document.querySelector('canvas');
                      return points.map(([s,d])=>({source:!!c&&document.elementFromPoint(...s)===c,
                        destination:!!c&&document.elementFromPoint(...d)===c}));
                    }""", points)
                    kept = []
                    for candidate, pair in zip(candidates, hits):
                        candidate["canvas_hit_tests"] = pair
                        if pair == {"source": True, "destination": True}:
                            kept.append(candidate)
                        else:
                            receipt["guard_refusals"].append(_reason(
                                "projected_endpoint_canvas_hit_test_failed",
                                candidate["source_id"], candidate["destination_id"], pair))
                    receipt["candidates"] = kept
            gaps = control_readiness_gaps(state, time.monotonic_ns() // 1_000_000)
            receipt["control_readiness_gaps"] = list(gaps)
            receipt["status"] = "PREVIEW_READY_FOR_ROOT_REVIEW" if receipt["candidates"] else "NO_ELIGIBLE_PAIR"
            receipt["operator_selection"] = None
            receipt["no_auto_target_or_send"] = True
            receipt["verdict"] = "READONLY_DIAGNOSTIC_CANDIDATES_ZERO_CREDIT"
    except asyncio.CancelledError:
        receipt["status"] = "PREVIEW_TIMEOUT"
        receipt["error"] = "bounded preview deadline expired"
        raise
    except Exception as exc:
        receipt["status"] = "PREVIEW_REJECTED"
        receipt["error"] = f"{type(exc).__name__}: {exc}"
        receipt["traceback"] = traceback.format_exc(limit=4)
    finally:
        if ex is not None:
            try:
                await asyncio.wait_for(ex.close(), timeout=2)
            except Exception as exc:
                receipt["cleanup_error"] = f"extractor close: {type(exc).__name__}: {exc}"
        receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        receipt["preview_id"] = uuid4().hex[:12]
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("x", encoding="utf-8") as stream:
            stream.write(json.dumps(receipt, default=state_json, ensure_ascii=False, indent=2) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
    return receipt


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True,
        help="new JSON receipt path under runtime/research/v2; existing files are never overwritten")
    args = parser.parse_args(argv)
    output = (ROOT / args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output).resolve()
    allowed = (ROOT / "runtime/research/v2").resolve()
    if allowed not in output.parents:
        parser.error("--output must be a new file inside runtime/research/v2")
    return output


async def main():
    output = parse_args().resolve()
    try:
        await asyncio.wait_for(_run(output), timeout=PREVIEW_TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        print(json.dumps({"status": "BOUNDED_TIMEOUT",
                          "receipt": str(output.relative_to(ROOT)),
                          "timeout_seconds": PREVIEW_TIMEOUT_SECONDS}), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
