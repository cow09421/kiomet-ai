"""Capture source for every broad public-DOM input listener on one owned page.

Prepared for a single <=60 second run against an already-running project-owned
headless browser. Importing or running this module never starts a host itself.
It does not arm the input observer, dispatch input, inspect actor payloads, or
call semantic WASM functions.
"""

import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import CLIENT_SHA256, ClientExtractor, connect_dedicated
from tools.v2_input_listener_evidence import capture_owned_memory_type
from tools.v2_controlled_transition_capture import is_project_headless_browser_process


RELEVANT_EVENTS = frozenset({
    "mousedown", "mouseup", "mousemove", "click", "dblclick",
    "pointerdown", "pointerup", "pointermove", "pointercancel",
    "touchstart", "touchend", "touchmove", "wheel",
})
BOUND_SECONDS = 20
OUTPUT_NAME = "listener-source-probe-20261002.json"
SOURCE_DIR_NAME = "listener-source-captures-20261002"


async def _value(cdp, expression):
    result = await cdp.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": True,
        "awaitPromise": False,
        "userGesture": False,
    })
    if result.get("exceptionDetails"):
        raise RuntimeError("public DOM metadata evaluation failed")
    remote = result.get("result") or {}
    if remote.get("subtype") == "error":
        raise RuntimeError("public DOM metadata evaluation returned an error")
    return remote.get("value")


async def _object(cdp, expression, handles):
    result = await cdp.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": False,
        "awaitPromise": False,
        "userGesture": False,
    })
    if result.get("exceptionDetails"):
        raise RuntimeError("DOM node handle evaluation failed")
    remote = result.get("result") or {}
    object_id = remote.get("objectId")
    if not isinstance(object_id, str):
        raise RuntimeError("DOM node handle is unavailable")
    handles.append(object_id)
    return object_id


async def _describe(cdp, object_id):
    response = await cdp.send("DOM.describeNode", {"objectId": object_id})
    node = response.get("node") or {}
    backend = node.get("backendNodeId")
    if type(backend) is not int or backend <= 0:
        raise RuntimeError("DOM backend node identity is unavailable")
    return backend


async def _frame(cdp):
    response = await cdp.send("Page.getFrameTree", {})
    frame = (response.get("frameTree") or {}).get("frame")
    if not isinstance(frame, dict):
        raise RuntimeError("main frame identity is unavailable")
    return {"frame_id": frame.get("id"), "loader_id": frame.get("loaderId"), "url": frame.get("url")}


async def _capture_nodes(cdp, handles):
    canvas_count = await _value(cdp, "document.querySelectorAll('canvas').length")
    if type(canvas_count) is not int or not 1 <= canvas_count <= 16:
        raise RuntimeError("canvas count is missing or outside bounded inventory")
    nodes_by_backend = {}
    for role, expression in (("window", "window"), ("document", "document")):
        oid = await _object(cdp, expression, handles)
        nodes_by_backend[(role, role)] = {"backend_node_id": None, "roles": [role], "object_id": oid}
    fixed = [
        ("html", "document.documentElement"),
        ("body", "document.body"),
    ]
    for role, expression in fixed:
        oid = await _object(cdp, expression, handles)
        backend = await _describe(cdp, oid)
        nodes_by_backend.setdefault(("backend", backend), {"backend_node_id": backend, "roles": [], "object_id": oid})["roles"].append(role)

    chains = []
    for canvas_index in range(canvas_count):
        canvas_expr = f"document.querySelectorAll('canvas')[{canvas_index}]"
        canvas_oid = await _object(cdp, canvas_expr, handles)
        chain = []
        node_oid = canvas_oid
        depth = 0
        while True:
            backend = await _describe(cdp, node_oid)
            chain.append(backend)
            key = ("backend", backend)
            node = nodes_by_backend.setdefault(key, {"backend_node_id": backend, "roles": [], "object_id": node_oid})
            role = f"canvas[{canvas_index}]" if depth == 0 else f"canvas[{canvas_index}]_ancestor_{depth}"
            if role not in node["roles"]:
                node["roles"].append(role)
            if depth == 0:
                # The generated canvas is ordinarily an HTMLCanvasElement;
                # tagName is read only to make node labeling explicit.
                tag = await _value(cdp, f"document.querySelectorAll('canvas')[{canvas_index}].tagName")
                if tag != "CANVAS":
                    raise RuntimeError("canvas selector returned an unexpected DOM element")
            is_null = await _value(cdp, f"(() => {{ let n=document.querySelectorAll('canvas')[{canvas_index}]; for(let j=0;j<{depth};j++) n=n?.parentElement; return n?.parentElement===null; }})()")
            if is_null is True:
                break
            parent = await _object(cdp, f"(() => {{ let n=document.querySelectorAll('canvas')[{canvas_index}]; for(let j=0;j<{depth};j++) n=n?.parentElement; return n?.parentElement ?? null; }})()", handles)
            node_oid = parent
            depth += 1
            if depth > 64:
                raise RuntimeError("canvas ancestry exceeded bound")
        chains.append({"canvas_index": canvas_index, "backend_node_ids": chain})
    return canvas_count, list(nodes_by_backend.values()), chains


async def capture_public_listener_sources(cdp, source_dir):
    """Inventory listeners and immediately retrieve each distinct script source."""
    handles = []
    debugger_enabled = False
    source_by_script = {}
    source_by_hash = {}
    failures = []
    try:
        await cdp.send("Debugger.enable", {})
        debugger_enabled = True
        frame_before = await _frame(cdp)
        time_origin_before = await _value(cdp, "performance.timeOrigin")
        status_before = await _value(cdp, "(() => { const o=window[Symbol.for('kiomet.inputEntryObserver.v1')]; return o && typeof o.status==='function' ? o.status() : null; })()")
        canvas_count, nodes, chains = await _capture_nodes(cdp, handles)

        inventory = []
        for node in nodes:
            response = await cdp.send("DOMDebugger.getEventListeners", {
                "objectId": node["object_id"], "depth": 0, "pierce": False,
            })
            listener_rows = response.get("listeners")
            if not isinstance(listener_rows, list):
                failures.append({"stage": "getEventListeners", "roles": node["roles"], "reason": "malformed response"})
                continue
            for listener in listener_rows:
                event_type = listener.get("type")
                if event_type not in RELEVANT_EVENTS:
                    continue
                script_id = listener.get("scriptId")
                row = {
                    "roles": list(node["roles"]),
                    "backend_node_id": node["backend_node_id"],
                    "event_type": event_type,
                    "use_capture": listener.get("useCapture"),
                    "passive": listener.get("passive"),
                    "once": listener.get("once"),
                    "script_id": script_id,
                    "line_number": listener.get("lineNumber"),
                    "column_number": listener.get("columnNumber"),
                }
                if not isinstance(script_id, str) or not script_id:
                    row["source_status"] = "SCRIPT_ID_UNAVAILABLE"
                    failures.append({"stage": "source", "row": row, "reason": "script id unavailable"})
                    inventory.append(row)
                    continue
                if script_id not in source_by_script:
                    try:
                        source_result = await cdp.send("Debugger.getScriptSource", {"scriptId": script_id})
                        script_source = source_result.get("scriptSource")
                        if not isinstance(script_source, str):
                            raise RuntimeError("getScriptSource did not return text")
                        source_bytes = script_source.encode("utf-8")
                        digest = hashlib.sha256(source_bytes).hexdigest()
                        target = source_dir / f"{digest}.js"
                        target.write_bytes(source_bytes)
                        source_by_script[script_id] = {"sha256": digest, "path": str(target.relative_to(ROOT))}
                        source_by_hash.setdefault(digest, {"sha256": digest, "path": str(target.relative_to(ROOT)), "script_ids": []})
                    except Exception as exc:
                        source_by_script[script_id] = {"error": type(exc).__name__}
                        failures.append({"stage": "getScriptSource", "script_id": script_id, "reason": type(exc).__name__})
                source_meta = source_by_script[script_id]
                if "sha256" in source_meta:
                    row["source_sha256"] = source_meta["sha256"]
                    row["source_path"] = source_meta["path"]
                    if script_id not in source_by_hash[source_meta["sha256"]]["script_ids"]:
                        source_by_hash[source_meta["sha256"]]["script_ids"].append(script_id)
                    row["source_status"] = "SAVED"
                else:
                    row["source_status"] = "SOURCE_UNAVAILABLE"
                inventory.append(row)

        # A post-read identity check brackets the source collection. It does
        # not claim to freeze asynchronous callbacks or game state.
        time_origin_after = await _value(cdp, "performance.timeOrigin")
        status_after = await _value(cdp, "(() => { const o=window[Symbol.for('kiomet.inputEntryObserver.v1')]; return o && typeof o.status==='function' ? o.status() : null; })()")
        frame_after = await _frame(cdp)
        identity_stable = frame_before == frame_after and time_origin_before == time_origin_after
        return {
            "document_id": None,
            "document_id_source": "not independently read; extractor UUID must be attached by caller",
            "main_frame_before": frame_before,
            "main_frame_after": frame_after,
            "time_origin_before_ms": time_origin_before,
            "time_origin_after_ms": time_origin_after,
            "observer_status_before": status_before,
            "observer_status_after": status_after,
            "identity_stable": identity_stable,
            "canvas_count": canvas_count,
            "canvas_chains": chains,
            "listener_inventory": inventory,
            "sources": list(source_by_hash.values()),
            "source_retrieval_complete": not failures and all(row.get("source_status") == "SAVED" for row in inventory),
            "failures": failures,
        }
    finally:
        for object_id in handles:
            try:
                await cdp.send("Runtime.releaseObject", {"objectId": object_id})
            except Exception:
                pass
        if debugger_enabled:
            try:
                await cdp.send("Debugger.disable", {})
            except Exception:
                pass


async def _run():
    import psutil
    output_dir = ROOT / "runtime/research/v2"
    lease = json.loads((output_dir / "headless-host.json").read_text(encoding="utf-8"))
    remaining = lease.get("deadline_monotonic_ms", 0) - time.monotonic_ns() / 1e6
    if remaining < 25_000:
        raise RuntimeError("existing host lease lacks the required 20-second capture plus cleanup margin")
    profile = (ROOT / "runtime/browser-profile").resolve()
    host_script = (ROOT / "tools/v2_headless_research.py").resolve()
    if (type(lease.get("pid")) is not int or lease["pid"] <= 0 or
            Path(lease.get("profile", "")).resolve() != profile):
        raise RuntimeError("headless host lease identity/profile is invalid")
    if (output_dir / "controlled-transition-writer.json").exists():
        raise RuntimeError("a controlled input writer lease exists; source capture refuses to overlap it")
    try:
        host_process = psutil.Process(lease["pid"])
        host_args = host_process.cmdline()
        if (not host_process.name().lower().startswith(("python", "py")) or
                not any(Path(arg).resolve() == host_script for arg in host_args if arg.lower().endswith(".py"))):
            raise RuntimeError("lease PID is not the expected v2 headless host")
        owners = []
        for child in host_process.children(recursive=True):
            try:
                child_args = child.cmdline()
                if is_project_headless_browser_process(child.name(), child_args, profile):
                    owners.append(child.pid)
            except psutil.Error:
                continue
        if len(owners) != 1:
            raise RuntimeError("host does not own exactly one verified headless Chromium process")
    except (psutil.Error, OSError) as exc:
        raise RuntimeError("headless host process ownership cannot be verified") from exc
    sources_dir = output_dir / SOURCE_DIR_NAME
    sources_dir.mkdir(parents=True, exist_ok=True)

    result = None
    async with async_playwright() as playwright:
        browser = await connect_dedicated(playwright, ROOT)
        pages = [page for context in browser.contexts for page in context.pages if page.url == "https://kiomet.com/"]
        if len(pages) != 1:
            raise RuntimeError("expected exactly one owned official page")
        page = pages[0]
        extractor = ClientExtractor(page)
        try:
            await extractor.attach()
            metadata = await extractor.metadata()
            memory = await capture_owned_memory_type(
                extractor.cdp, memories_id=extractor.memories_id,
                expected_time_origin_ms=extractor.time_origin,
            )
            if memory.get("qualified") is not True:
                raise RuntimeError("owned memory type could not be proven from the extractor handle")
            metadata = {
                **metadata,
                "client_sha256": CLIENT_SHA256,
                "shared_memory": memory["evidence"]["shared_memory"],
                "metadata_provenance": "CALLER_ATTESTED_FRESH_EXTRACTOR_SAMPLE",
            }
            inventory = await capture_public_listener_sources(extractor.cdp, sources_dir)
            inventory["document_id"] = extractor.document_id
            inventory["document_id_source"] = "CALLER_ATTESTED_CURRENT_EXTRACTOR_SESSION_UUID"
            identity_ok = (
                inventory["identity_stable"] is True and
                inventory["main_frame_before"].get("url") == "https://kiomet.com/" and
                inventory["time_origin_before_ms"] == extractor.time_origin and
                inventory["time_origin_after_ms"] == extractor.time_origin
            )
            observer_pristine = all(
                isinstance(inventory.get(key), dict) and
                inventory[key].get("installed") is True and
                inventory[key].get("status") == "DISARMED" and
                inventory[key].get("armed_once") is False
                for key in ("observer_status_before", "observer_status_after")
            )
            inventory["observer_pristine_before_after"] = observer_pristine
            result = {
                "QUESTION": "Which exact JavaScript sources own broad relevant input listeners in the current official headless document?",
                "BEFORE": {
                    "document_id": extractor.document_id,
                    "document_id_source": "caller-attested extractor session UUID",
                    "document_time_origin_ms": extractor.time_origin,
                    "client_sha256": CLIENT_SHA256,
                    "transport_mode": metadata.get("transport_mode"),
                    "transport_connected": metadata.get("transport_connected"),
                    "owned_transports": metadata.get("owned_transports"),
                    "memory_type": memory,
                },
                "ACTION": {
                    "observer_arms": 0,
                    "troop_gestures": 0,
                    "wheel_events": 0,
                    "keyboard_events": 0,
                    "DOM_mutations": 0,
                    "CDP_listener_source_queries": True,
                },
                "EXPECTED": {
                    "one_owned_official_page": True,
                    "stable_main_frame_loader_and_time_origin": True,
                    "all_broad_relevant_listener_scripts_saved_by_sha256": True,
                    "listener_ids_include_unknown_click_source_7aa7f8a0357267423b6a42499e6cfb4ab34bed6c84bce4ee5134ed9f20662df1": True,
                    "route_or_gesture_certificate": "NONE",
                },
                "OBSERVED": inventory,
                "SIMULATED": "Not applicable; no world command or game simulation.",
                "DIFF": "Unknown until sources are independently reviewed against the pinned event path.",
                "VERDICT": "DIAGNOSTIC_ONLY_ZERO_FORMAL_CREDIT" if identity_ok and observer_pristine and inventory["source_retrieval_complete"] else "INCOMPLETE_DIAGNOSTIC_ZERO_CREDIT",
                "source_directory": str(sources_dir.relative_to(ROOT)),
            }
            path = output_dir / OUTPUT_NAME
            path.write_text(json.dumps(result, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
            print(json.dumps({
                "output": str(path),
                "listener_rows": len(inventory["listener_inventory"]),
                "source_count": len(inventory["sources"]),
                "source_retrieval_complete": inventory["source_retrieval_complete"],
                "identity_stable": inventory["identity_stable"],
                "unknown_click_source_seen": any(source["sha256"] == "7aa7f8a0357267423b6a42499e6cfb4ab34bed6c84bce4ee5134ed9f20662df1" for source in inventory["sources"]),
                "troop_gestures": 0,
                "observer_arms": 0,
            }))
        finally:
            await extractor.close()


if __name__ == "__main__":
    asyncio.run(asyncio.wait_for(_run(), timeout=BOUND_SECONDS))
