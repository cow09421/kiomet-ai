import asyncio, json, sys, time, importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import connect_dedicated
spec=importlib.util.spec_from_file_location('friendly_preview',ROOT/'runtime/research/v2/friendly-fast-preview-20261002.py')
preview=importlib.util.module_from_spec(spec);spec.loader.exec_module(preview)
async def main():
    out=ROOT/'runtime/research/v2'
    receipt=json.loads((out/'menu-scene-selector-plan-20261002.json').read_text(encoding='utf8'))
    path=out/'menu-scene-selector-20261002.json'
    try:
        lease,margin=await preview._owned_headless_lease(out)
        if lease.get('input_entry_observer',{}).get('observer_requested') is not False:
            raise ValueError('read-only menu census requires observer disabled')
        receipt['lease_margin_ms']=margin
        async with async_playwright() as pw:
            browser=await connect_dedicated(pw,ROOT)
            pages=[p for c in browser.contexts for p in c.pages if p.url=='https://kiomet.com/']
            if len(pages)!=1:raise ValueError('exactly one owned official page required')
            page=pages[0]
            if not await page.locator('#play_button').is_visible():
                raise ValueError('normal main-menu play control is not visible')
            receipt['OBSERVED']=await page.evaluate("""() => {
                const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
                const text=e=>(e.innerText||e.textContent||'').trim().slice(0,240);
                return {url:location.origin+location.pathname,title:document.title,observer_present:!!window[Symbol.for('kiomet.inputEntryObserver.v1')],
                    play_label:text(document.querySelector('#play_button')),
                    controls:Array.from(document.querySelectorAll('button,select,[role=button],input,a')).filter(visible).slice(0,120).map(e=>({tag:e.tagName,id:e.id,type:e.getAttribute('type'),label:text(e),aria_label:e.getAttribute('aria-label'),title:e.getAttribute('title'),placeholder:e.getAttribute('placeholder'),role:e.getAttribute('role'),href:e.tagName==='A'?e.getAttribute('href'):null,options:e.tagName==='SELECT'?Array.from(e.selectedOptions).map(o=>({label:o.text,selected:true})):null})),
                    headings:Array.from(document.querySelectorAll('h1,h2,h3')).filter(visible).map(text)};
                }""")
        receipt['DIFF']='Only visible DOM control descriptions observed; no storage, credentials, hidden settings, actor payloads, or game inputs accessed.'
        receipt['VERDICT']='READONLY_MAIN_MENU_INVENTORY_ZERO_FORMAL_CREDIT'
    except Exception as exc:
        receipt['OBSERVED']={'error':str(exc)}
        receipt['VERDICT']='REFUSED_OR_FAILED_ZERO_FORMAL_CREDIT'
    receipt['formal_credit']=0
    with path.open('x',encoding='utf8') as f:json.dump(receipt,f,indent=2,ensure_ascii=False)
    print(json.dumps({'output':str(path),'verdict':receipt['VERDICT']}))
asyncio.run(asyncio.wait_for(main(),timeout=20))
