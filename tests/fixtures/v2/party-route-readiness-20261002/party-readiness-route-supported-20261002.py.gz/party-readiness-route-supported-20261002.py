"""One bounded Party UI join and strict NETWORK readiness survey; no troops or observer arm."""
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

from playwright.async_api import async_playwright

from kiomet_ai.v2.observe.extractor import (
    ClientExtractor, connect_dedicated, is_official_client_url,
)
from tools.v2_controlled_transition_capture import (
    _sample_ready, control_readiness_gaps, state_json,
)


OUT = ROOT / "runtime/research/v2"
PLAN = OUT / "party-readiness-route-supported-plan-20261002.json"
RECEIPT = OUT / "party-readiness-route-supported-20261002.json"
ROOT_URL = "https://kiomet.com/"

CENSUS = """() => {
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
 const text=e=>(e.innerText||e.textContent||'').trim().slice(0,160);
 const o=window[Symbol.for('kiomet.inputEntryObserver.v1')]?.status();
 return {origin:location.origin,document_origin_ms:performance.timeOrigin,
 observer:o?{status:o.status,armed_once:o.armed_once,armed:o.armed,installed:o.installed}:null,
 controls:Array.from(document.querySelectorAll('button,select,[role=button],input,a,label')).filter(visible).slice(0,160).map(e=>({tag:e.tagName,id:e.id,type:e.getAttribute('type'),label:text(e),title:e.getAttribute('title'),placeholder:e.getAttribute('placeholder'),checked:e.matches('input[type=radio],input[type=checkbox]')?e.checked:null,selected_option_labels:e.tagName==='SELECT'?Array.from(e.selectedOptions).map(o=>o.text):null})),
 headings:Array.from(document.querySelectorAll('h1,h2,h3')).filter(visible).map(text)};
}"""


def save(receipt):
    with RECEIPT.open("w", encoding="utf8", newline="\n") as stream:
        json.dump(receipt, stream, default=state_json, indent=2, ensure_ascii=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


async def main():
    spec = importlib.util.spec_from_file_location(
        "friendly_preview", OUT / "friendly-fast-preview-20261002.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("bounded preview lease helper unavailable")
    preview = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preview)

    receipt = json.loads(PLAN.read_text(encoding="utf8"))
    receipt["actual_actions"] = []
    receipt["OBSERVED"] = []
    phase = "LEASE_PREFLIGHT"
    extractor = None

    async def action(kind, fn):
        receipt["actual_actions"].append({"kind": kind, "phase": "ATTEMPTED"})
        save(receipt)
        await fn()
        receipt["actual_actions"][-1]["phase"] = "COMPLETED"
        save(receipt)

    async def scene_page(browser):
        shape = re.compile(r"https://kiomet\.com/(?:[A-Z]{6}/)?(?:play-with-friends/)?")
        pages = [page for context in browser.contexts for page in context.pages
                 if shape.fullmatch(page.url)]
        if len(pages) != 1:
            raise ValueError("exactly one current official scene page required")
        return pages[0]

    async def official_page(browser):
        pages = [page for context in browser.contexts for page in context.pages
                 if is_official_client_url(page.url)]
        if len(pages) != 1:
            raise ValueError("exactly one current official page required")
        return pages[0]

    try:
        lease, margin = await preview._owned_headless_lease(OUT)
        receipt["lease_margin_ms"] = margin
        if margin < 60000:
            raise ValueError("60 seconds required for finite route setup")
        observer_lease = lease.get("input_entry_observer", {})
        if observer_lease.get("observer_requested") is not True:
            raise ValueError("pre-start observer required")

        async with async_playwright() as pw:
            browser = await connect_dedicated(pw, ROOT)
            page = await official_page(browser)
            if page.url != ROOT_URL:
                raise ValueError("normal root menu required before Party setup")
            if not await page.locator("#play_button").is_visible():
                raise ValueError("normal root Play control absent")
            receipt["BEFORE_OBSERVED"] = await page.evaluate(CENSUS)
            observer = receipt["BEFORE_OBSERVED"].get("observer")
            if (not observer or observer.get("installed") is not True or
                    observer.get("status") != "DISARMED" or
                    observer.get("armed_once") is not False or
                    observer.get("armed") is not False):
                raise ValueError("observer must start installed and DISARMED")
            save(receipt)

            phase = "OPEN_FRIENDS"
            await action("OPEN_FRIENDS", lambda: page.locator(
                "#play_with_friends_button").click(timeout=5000))
            party = page.locator("input#party[type=radio]")
            if not await party.is_visible():
                raise ValueError("normal Party radio absent")
            if not await party.is_checked():
                phase = "SELECT_PARTY"
                await action("SELECT_PARTY", lambda: party.check(timeout=5000))
            if not await party.is_checked():
                raise ValueError("Party selection not confirmed")
            receipt["PARTY_SELECTED"] = await page.evaluate(CENSUS)
            save(receipt)
            await page.wait_for_timeout(1800)

            page = await scene_page(browser)
            settled = await page.evaluate(CENSUS)
            receipt["SETTLED_PARTY_UI"] = settled
            save(receipt)
            observer = settled.get("observer")
            if (not observer or observer.get("status") != "DISARMED" or
                    observer.get("armed_once") is not False or
                    observer.get("armed") is not False):
                raise ValueError("observer must remain DISARMED before Play")
            if "Play with friends" in settled.get("headings", []):
                if not await page.locator("#party").is_checked():
                    raise ValueError("Party selection changed while dialog remains")
                play = page.locator("button:not(#play_button)").filter(
                    has_text=re.compile(r"^Play$"))
            else:
                play = page.locator("#play_button")
            if (await play.count() != 1 or not await play.is_visible() or
                    not await play.is_enabled()):
                raise ValueError("single current normal Play control required")

            phase = "NORMAL_PLAY"
            await action("NORMAL_PLAY", lambda: play.click(timeout=5000))
            await page.wait_for_timeout(1500)
            page = await official_page(browser)
            if page.url == ROOT_URL:
                raise ValueError("joined party route not established")
            await page.locator("#play_button").wait_for(state="hidden", timeout=10000)
            post_join = await page.evaluate(CENSUS)
            receipt["POST_JOIN_UI"] = post_join
            # Store only the route class; never persist the party code in the URL path.
            receipt["POST_JOIN_ROUTE"] = "OFFICIAL_PARTY_ROUTE"
            save(receipt)
            observer = post_join.get("observer")
            if (not observer or observer.get("status") != "DISARMED" or
                    observer.get("armed_once") is not False or
                    observer.get("armed") is not False):
                raise ValueError("observer must remain DISARMED after join")

            phase = "CANONICAL_NETWORK_SURVEY"
            extractor = ClientExtractor(page)
            await extractor.attach()
            survey_end = time.monotonic() + 5
            while time.monotonic() < survey_end:
                state, _raw = await _sample_ready(extractor)
                gaps = control_readiness_gaps(state, time.monotonic_ns() // 1_000_000)
                sample = {"state": state, "gaps": list(gaps)}
                if state.source_mode.value != "NETWORK":
                    sample["source_mode_refusal"] = "strict NETWORK required"
                    receipt["OBSERVED"].append(sample)
                    save(receipt)
                    raise ValueError("canonical source mode is not NETWORK")
                receipt["OBSERVED"].append(sample)
                save(receipt)
                await asyncio.sleep(.1)
            await extractor.close()
            extractor = None
            receipt["VERDICT"] = (
                "STRICT_NETWORK_READINESS_GAP_FREE" if receipt["OBSERVED"] and
                all(not row["gaps"] for row in receipt["OBSERVED"])
                else "STRICT_NETWORK_SURVEY_WITH_GAPS_RETAINED")
    except Exception as exc:
        receipt["failure_phase"] = phase
        # Persist exception class only; browser errors may contain the private party URL.
        receipt["error_type"] = type(exc).__name__
        receipt["VERDICT"] = "REFUSED_OR_FAILED_ZERO_TROOPS"
    finally:
        if extractor is not None:
            try:
                await extractor.close()
            except Exception:
                receipt["extractor_close_error"] = True
        receipt["DIFF"] = (
            "One ordinary Party UI flow at most; no troop gesture, observer arm, hidden actor access, "
            "semantic WASM command, clipboard, or human message. Unknown facts and readiness gaps retained.")
        receipt["formal_credit"] = 0
        save(receipt)
        print(json.dumps({"output": str(RECEIPT), "verdict": receipt["VERDICT"],
                          "samples": len(receipt["OBSERVED"])}), flush=True)


if __name__ == "__main__":
    asyncio.run(asyncio.wait_for(main(), timeout=35))
