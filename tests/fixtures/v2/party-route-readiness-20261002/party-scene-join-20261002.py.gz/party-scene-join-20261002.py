import asyncio,json,re,sys,time,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import connect_dedicated,ClientExtractor
from tools.v2_controlled_transition_capture import _sample_ready,state_json,control_readiness_gaps
spec=importlib.util.spec_from_file_location('party_probe',ROOT/'runtime/research/v2/party-scene-probe-20261002.py')
# Read the frozen census text without executing the previous probe module.
source=(ROOT/'runtime/research/v2/party-scene-probe-20261002.py').read_text(encoding='utf8')
import ast
CENSUS=next(ast.literal_eval(n.value) for n in ast.parse(source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CENSUS' for t in n.targets))
spec=importlib.util.spec_from_file_location('friendly_preview',ROOT/'runtime/research/v2/friendly-fast-preview-20261002.py')
preview=importlib.util.module_from_spec(spec);spec.loader.exec_module(preview)
async def main():
 out=ROOT/'runtime/research/v2';path=out/'party-scene-join-20261002.json'
 receipt=json.loads((out/'party-scene-join-plan-20261002.json').read_text(encoding='utf8'));ex=None
 def save():
  with path.open('w',encoding='utf8') as f:json.dump(receipt,f,default=state_json,indent=2,ensure_ascii=False)
 try:
  lease,margin=await preview._owned_headless_lease(out);receipt['lease_margin_ms']=margin
  if lease.get('input_entry_observer',{}).get('observer_requested') is not True:raise ValueError('prestart observer required')
  async with async_playwright() as pw:
   browser=await connect_dedicated(pw,ROOT)
   pages=[p for c in browser.contexts for p in c.pages if p.url.startswith('https://kiomet.com/play-with-friends/')]
   if len(pages)!=1:raise ValueError('one observed official friends-dialog page required')
   page=pages[0]
   if not await page.locator('#party').is_checked():raise ValueError('observed party radio must remain checked')
   receipt['BEFORE_OBSERVED']=await page.evaluate(CENSUS);save()
   obs=receipt['BEFORE_OBSERVED']['observer']
   if not obs or obs['status']!='DISARMED' or obs['armed_once'] is not False:raise ValueError('observer must remain unused')
   play=page.locator('button:not(#play_button)').filter(has_text=re.compile(r'^Play$'))
   if await play.count()!=1 or not await play.is_visible() or not await play.is_enabled():raise ValueError('exact single observed dialog Play required')
   receipt['ACTION']['dialog_Play_attempted']=True;save()
   await play.click(timeout=5000)
   receipt['ACTION']['dialog_Play_completed']=True;save()
   await page.locator('#play_button').wait_for(state='hidden',timeout=10000)
   receipt['POST_JOIN_UI']=await page.evaluate(CENSUS);save()
   ex=ClientExtractor(page);await ex.attach()
   end=time.monotonic()+5
   while time.monotonic()<end:
    state,raw=await _sample_ready(ex)
    receipt['OBSERVED'].append({'state':state,'gaps':control_readiness_gaps(state,time.monotonic_ns()//1000000)})
    if state.source_mode.value!='NETWORK':raise ValueError('network source required')
    await asyncio.sleep(.1)
   await ex.close();ex=None
   receipt['VERDICT']='NORMAL_PARTY_DIALOG_PLAY_AND_NETWORK_READINESS_SURVEY'
 except Exception as exc:receipt['error']=str(exc);receipt['VERDICT']='REFUSED_OR_FAILED_ZERO_TROOPS'
 finally:
  if ex is not None:
   try:await ex.close()
   except Exception as exc:receipt['extractor_close_error']=str(exc)
  receipt['formal_credit']=0
  receipt['DIFF']='Scene readiness only; all required unknown fields retained; no troops or arm/copy/share.'
  save();print(json.dumps({'output':str(path),'verdict':receipt['VERDICT'],'samples':len(receipt['OBSERVED'])}))
asyncio.run(asyncio.wait_for(main(),timeout=25))
