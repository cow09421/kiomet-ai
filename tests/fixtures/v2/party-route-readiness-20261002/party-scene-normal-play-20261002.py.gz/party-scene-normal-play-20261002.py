import asyncio,json,sys,time,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import connect_dedicated,ClientExtractor
from tools.v2_controlled_transition_capture import _sample_ready,state_json,control_readiness_gaps
spec=importlib.util.spec_from_file_location('friendly_preview',ROOT/'runtime/research/v2/friendly-fast-preview-20261002.py')
preview=importlib.util.module_from_spec(spec);spec.loader.exec_module(preview)
CENSUS="""() => {
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
 const text=e=>(e.innerText||e.textContent||'').trim().slice(0,160);
 const o=window[Symbol.for('kiomet.inputEntryObserver.v1')]?.status();
 return {url_path:location.origin+location.pathname,query_keys:Array.from(new URL(location.href).searchParams.keys()),document_origin_ms:performance.timeOrigin,
 observer:o?{status:o.status,armed_once:o.armed_once,armed:o.armed,installed:o.installed}:null,
 controls:Array.from(document.querySelectorAll('button,select,[role=button],input,a,label')).filter(visible).slice(0,160).map(e=>({tag:e.tagName,id:e.id,type:e.getAttribute('type'),label:text(e),title:e.getAttribute('title'),placeholder:e.getAttribute('placeholder'),checked:e.matches('input[type=radio],input[type=checkbox]')?e.checked:null,selected_option_labels:e.tagName==='SELECT'?Array.from(e.selectedOptions).map(o=>o.text):null})),
 headings:Array.from(document.querySelectorAll('h1,h2,h3')).filter(visible).map(text)};
}"""
async def main():
 out=ROOT/'runtime/research/v2';path=out/'party-scene-normal-play-20261002.json'
 receipt=json.loads((out/'party-scene-normal-play-plan-20261002.json').read_text(encoding='utf8'));receipt['actual_actions']=[];ex=None
 def save():
  with path.open('w',encoding='utf8') as f:json.dump(receipt,f,default=state_json,indent=2,ensure_ascii=False)
 async def action(kind,fn):
  receipt['actual_actions'].append({'kind':kind,'phase':'ATTEMPTED'});save()
  await fn();receipt['actual_actions'][-1]['phase']='COMPLETED';save()
 async def official_page(browser):
  from urllib.parse import urlsplit
  pages=[p for c in browser.contexts for p in c.pages if urlsplit(p.url).scheme=='https' and urlsplit(p.url).hostname=='kiomet.com']
  if len(pages)!=1:raise ValueError('exactly one current official owned page required')
  return pages[0]
 try:
  lease,margin=await preview._owned_headless_lease(out);receipt['lease_margin_ms']=margin
  if margin<60000:raise ValueError('60 seconds required for finite scene setup')
  if lease.get('input_entry_observer',{}).get('observer_requested') is not True:raise ValueError('prestart observer required')
  async with async_playwright() as pw:
   browser=await connect_dedicated(pw,ROOT);page=await official_page(browser)
   if not await page.locator('#play_button').is_visible():raise ValueError('normal menu required')
   receipt['BEFORE_OBSERVED']=await page.evaluate(CENSUS);save()
   await action('OPEN_FRIENDS',lambda:page.locator('#play_with_friends_button').click(timeout=5000))
   party=page.locator('input#party[type=radio]')
   if not await party.is_visible():raise ValueError('observed party choice absent')
   if not await party.is_checked():await action('SELECT_PARTY',lambda:party.check(timeout=5000))
   if not await party.is_checked():raise ValueError('party selection not confirmed')
   receipt['PARTY_SELECTED']=await page.evaluate(CENSUS);save()
   await page.wait_for_timeout(1800)
   page=await official_page(browser);receipt['SETTLED_PARTY_UI']=await page.evaluate(CENSUS);save()
   obs=receipt['SETTLED_PARTY_UI']['observer']
   if not obs or obs['status']!='DISARMED' or obs['armed_once'] is not False:raise ValueError('observer must remain unused')
   import re
   if 'Play with friends' in receipt['SETTLED_PARTY_UI']['headings']:
    if not await page.locator('#party').is_checked():raise ValueError('party changed while dialog remains')
    play=page.locator('button:not(#play_button)').filter(has_text=re.compile(r'^Play$'))
   else:play=page.locator('#play_button')
   if await play.count()!=1 or not await play.is_visible() or not await play.is_enabled():raise ValueError('single current normal Play required')
   await action('NORMAL_PLAY',lambda:play.click(timeout=5000))
   await page.wait_for_timeout(1500)
   page=await official_page(browser)
   await page.locator('#play_button').wait_for(state='hidden',timeout=10000)
   receipt['POST_JOIN_UI']=await page.evaluate(CENSUS);save()
   ex=ClientExtractor(page);await ex.attach()
   end=time.monotonic()+5
   while time.monotonic()<end:
    state,raw=await _sample_ready(ex)
    receipt['OBSERVED'].append({'state':state,'gaps':control_readiness_gaps(state,time.monotonic_ns()//1000000)})
    if state.source_mode.value!='NETWORK':raise ValueError('network source required')
    await asyncio.sleep(.1)
   await ex.close();ex=None
   receipt['VERDICT']='NORMAL_PARTY_UI_JOIN_AND_STRICT_NETWORK_READINESS_SURVEY'
 except Exception as exc:receipt['error']=str(exc);receipt['VERDICT']='REFUSED_OR_FAILED_ZERO_TROOPS'
 finally:
  if ex is not None:
   try:await ex.close()
   except Exception as exc:receipt['extractor_close_error']=str(exc)
  receipt['DIFF']='No troop gesture, observer arm, hidden actor access, semantic WASM command, clipboard, or human message; unknown facts retained.'
  receipt['formal_credit']=0;save()
  print(json.dumps({'output':str(path),'verdict':receipt['VERDICT'],'samples':len(receipt['OBSERVED'])}))
asyncio.run(asyncio.wait_for(main(),timeout=35))
