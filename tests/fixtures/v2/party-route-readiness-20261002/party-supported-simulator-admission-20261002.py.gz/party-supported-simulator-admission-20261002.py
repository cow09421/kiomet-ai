from __future__ import annotations
import copy, gzip, hashlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'tools'))
from kiomet_ai.v2.serialization import state_from_dict
from kiomet_ai.v2.sim import from_canonical, step, UnsupportedState, Scenario
from v2_sim_differential import signature, input_event_categories

BASE=ROOT/'runtime/research/v2'
FIXTURE=ROOT/'tests/fixtures/v2/party-route-readiness-20261002/party-readiness-route-supported-2-20261002.json.gz'
EXPECTED=BASE/'party-supported-simulator-admission-20261002.json'
OUT=BASE/'party-supported-simulator-admission-reproduced-20261002.json'

def counts(a,b):
    aa={t.id:t for t in a.towers}; bb={t.id:t for t in b.towers}
    return {'tower_owner_changes':sum(aa[i].owner!=bb[i].owner for i in aa.keys()&bb.keys()),
      'tower_kind_changes':sum(aa[i].kind!=bb[i].kind for i in aa.keys()&bb.keys()),
      'tower_unit_vector_changes':sum(aa[i].units!=bb[i].units for i in aa.keys()&bb.keys()),
      'tower_aura_changes':sum(aa[i].morale!=bb[i].morale for i in aa.keys()&bb.keys()),
      'tower_capacity_changes':sum(aa[i].capacity!=bb[i].capacity for i in aa.keys()&bb.keys()),
      'tower_production_changes':sum(aa[i].production!=bb[i].production for i in aa.keys()&bb.keys()),
      'force_count_before':len(a.forces),'force_count_after':len(b.forces)}

def main():
    source=json.load(gzip.open(FIXTURE,'rt',encoding='utf-8'))
    samples=source['OBSERVED']
    states=[state_from_dict(row['state']) for row in samples]
    canonical=[from_canonical(s) for s in states]
    expected=json.loads(EXPECTED.read_text(encoding='utf-8'))
    out=copy.deepcopy(expected)
    restored=len(states); gaps=sum(bool(row.get('gaps')) for row in samples)
    fail=[]; single_pass=0
    for i,s in enumerate(canonical):
        try: step(s,scenario=Scenario(fixed_morale=True)); single_pass+=1
        except UnsupportedState as e: fail.append({'sample':i+1,'tick':s.world_sequence,'reason':str(e).split(':')[0]})
    out['canonical_readiness']['restored_samples']=restored
    out['canonical_readiness']['restore_failures']=0
    out['canonical_readiness']['states_with_control_readiness_gaps']=gaps
    out['single_state_step']={'pass':single_pass,'first_failure:UNKNOWN_POST_ARRIVAL_PATH':len(fail)}
    out['state_first_failures']=fail
    pair_rows=[]; repeat=multi=0; step_pass=match=reject=0
    for i in range(1,len(states)):
        a,b=states[i-1],states[i]
        delta=(b.tick.value-a.tick.value)%65536
        if delta==0: repeat+=1; continue
        if delta!=1: multi+=1; continue
        ca,cb=canonical[i-1],canonical[i]
        rec={'pair_ordinal':i+1,'before_tick':ca.world_sequence,'after_tick':cb.world_sequence,
             'before_event_categories':input_event_categories(ca),'observed_delta_counts':counts(ca,cb)}
        try:
            pred=step(ca,scenario=Scenario(fixed_morale=True)); step_pass+=1
            same=signature(pred)==signature(cb); match+=same
            rec['comparison']='EXACT_SIGNATURE_MATCH' if same else 'SIGNATURE_MISMATCH'
        except UnsupportedState as e:
            reject+=1; rec.update(admission='STEP_REJECTED',first_failure=str(e).split(':')[0])
        pair_rows.append(rec)
    out['pair_timeline']={'repeat_same_tick':repeat,'exact_consecutive':len(pair_rows),'step_pass':step_pass,
        'signature_match':match,'signature_mismatch':step_pass-match,'multi_tick_gap':multi,
        'step_rejected:UNKNOWN_POST_ARRIVAL_PATH':reject}
    out['pairs']=pair_rows
    # Keep the documented before-only interpretation and candidate UNKNOWN values from the independently recorded review.
    out['reproduction']={'fixture':str(FIXTURE.relative_to(ROOT)).replace('\\','/'),
      'fixture_sha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
      'scenario':{'fixed_morale':True,'diagnostic_premise_only':True,'formal_credit':0},
      'pair_signatures':'tools/v2_sim_differential.signature over strict state_from_dict -> from_canonical -> step results'}
    OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(OUT),'samples':restored,'readiness_gaps':gaps,
      'single_pass':single_pass,'first_failures':fail,'pair_timeline':out['pair_timeline'],
      'expected_aggregates':expected['pair_timeline'],'actual_aggregates':out['pair_timeline']},indent=2))
if __name__=='__main__': main()
