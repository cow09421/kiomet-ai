import asyncio,json,sys,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from playwright.async_api import async_playwright
from kiomet_ai.v2.observe.extractor import connect_dedicated
spec=importlib.util.spec_from_file_location('friendly_preview',ROOT/'runtime/research/v2/friendly-fast-preview-20261002.py')
preview=importlib.util.module_from_spec(spec);spec.loader.exec_module(preview)
CENSUS="""() => {
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
 const text=e=>(e.innerText||e.textContent||'').trim().slice(0,240);
 return {url_path:location.origin+location.pathname,document_origin_ms:performance.timeOrigin,observer_present:!!window[Symbol.for('kiomet.inputEntryObserver.v1')],
 controls:Array.from(document.querySelectorAll('button,select,[role=button],input,a')).filter(visible).slice(0,140).map(e=>({tag:e.tagName,id:e.id,type:e.getAttribute('type'),label:text(e),aria_label:e.getAttribute('aria-label'),title:e.getAttribute('title'),placeholder:e.getAttribute('placeholder'),role:e.getAttribute('role'),selected_option_labels:e.tagName==='SELECT'?Array.from(e.selectedOptions).map(o=>o.text):null})),
 headings:Array.from(document.querySelectorAll('h1,h2,h3,[role=dialog] label,[role=dialog] p')).filter(visible).map(text)};
}"""
async def main():
 out=ROOT/'runtime/research/v2';path=out/'play-with-friends-options-20261002.json'
 receipt=json.loads((out/'play-with-friends-options-plan-20261002.json').read_text(encoding='utf8'))
 receipt['ACTION']['normal_button_click_attempted']=False
 receipt['ACTION']['normal_button_click_completed']=False
 try:
  lease,margin=await preview._owned_headless_lease(out)
  if lease.get('input_entry_observer',{}).get('observer_requested') is not False:raise ValueError('observer must be disabled')
  receipt['lease_margin_ms']=margin
  async with async_playwright() as pw:
   browser=await connect_dedicated(pw,ROOT)
   pages=[p for c in browser.contexts for p in c.pages if p.url=='https://kiomet.com/']
   if len(pages)!=1:raise ValueError('exactly one dedicated official page required')
   page=pages[0]
   if not await page.locator('#play_button').is_visible():raise ValueError('normal main menu required')
   if not await page.locator('#play_with_friends_button').is_visible():raise ValueError('friends button unavailable')
   receipt['BEFORE_OBSERVED']=await page.evaluate(CENSUS)
   with path.open('x',encoding='utf8') as f:json.dump(receipt,f,indent=2,ensure_ascii=False)
   receipt['ACTION']['normal_button_click_attempted']=True
   await page.locator('#play_with_friends_button').click(timeout=5000)
   receipt['ACTION']['normal_button_click_completed']=True
   await page.wait_for_timeout(300)
   receipt['OBSERVED']=await page.evaluate(CENSUS)
   if receipt['OBSERVED']['document_origin_ms']!=receipt['BEFORE_OBSERVED']['document_origin_ms']:raise ValueError('document replaced; stop')
   receipt['DIFF']='One ordinary menu click; visible controls only; no choice, invite submission, clipboard action, storage read or actor/world access.'
   receipt['VERDICT']='BOUNDED_DIALOG_OBSERVATION_ZERO_FORMAL_CREDIT'
 except Exception as exc:
  receipt['error']=str(exc);receipt['VERDICT']='REFUSED_OR_FAILED_ZERO_FORMAL_CREDIT'
 receipt['formal_credit']=0
 with path.open('w',encoding='utf8') as f:json.dump(receipt,f,indent=2,ensure_ascii=False)
 print(json.dumps({'output':str(path),'verdict':receipt['VERDICT']}))
asyncio.run(asyncio.wait_for(main(),timeout=20))
